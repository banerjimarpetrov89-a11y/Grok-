import {
  ACTIVITIES,
  FUND_NOTE,
  NEGATIVE_NOTE,
  PACKAGE_BLURB,
  PHASES,
  SCORECARD,
  THEME_NAME,
  type Activity,
  type PackageAmount,
  activitiesIn,
  directionWord,
  packageTotal,
  phaseText,
  tierLabel,
} from "./catalogue.ts";
import { ALL_THEMES, THEME_OFFICIAL, blockEnvelope, firstActivities, hotThemes, rankedGps, recommend } from "./gps.ts";

function themeList(a: Activity): string {
  return a.themes.map((t) => `T${t} ${THEME_NAME[t]}`).join("; ");
}

export function readmeRows(): string[][] {
  const lines = [
    "Balumath block, Latehar district — GPDP Child Protection Activity Catalogue",
    "For the District Panchayat Raj Officer, the Block Development Officer, and the Gram Panchayat. People's plan campaign for FY 2027-28.",
    "PAI baseline: theme-wise scores of 13 Gram Panchayats, Balumath block, 2022-23. Use them until the DPRO replaces the sheet. The activity list does not depend on one year; the GP-wise file does.",
    "38 activities. Themes in scope: 2 Healthy, 3 Child Friendly, 6 Infrastructure, 7 Socially just, 8 Good governance, 9 Women friendly. Health, ICDS, mothers, nutrition, IEC and child protection are all inside these six. Themes 1, 4 and 5 are in the GP sheet so they are not forgotten, and they are not funded from these three files.",
    "Three ready files, per GP, per year. They nest: the ₹1,00,000 file contains the ₹50,000 file; the ₹2,00,000 file contains the ₹1,00,000 file.",
    `₹50,000 — ${PACKAGE_BLURB[50000].title}. ${PACKAGE_BLURB[50000].refuses}`,
    `₹1,00,000 — ${PACKAGE_BLURB[100000].title}. ${PACKAGE_BLURB[100000].adds}`,
    `₹2,00,000 — ${PACKAGE_BLURB[200000].title}. ${PACKAGE_BLURB[200000].adds} ${PACKAGE_BLURB[200000].refuses}`,
    "Recommendation rule, applied on the Balumath GPs sheet: ₹2,00,000 if overall PAI is Beginner, or Theme 9 is under 45, or Theme 6 is under 32, or Theme 8 is under 39, or Theme 3 is under 41.5, or Theme 7 is under 50. Otherwise ₹1,00,000. The ₹50,000 file is a fallback, not a recommendation. On this baseline that is 9 GPs at ₹2,00,000 and 4 at ₹1,00,000 (Sheregara, Basiya, Ganeshpur, Masiyatu). Block envelope if each GP adopts it: ₹22,00,000.",
    "How to enter on eGramSwaraj: pick the file, add each line as its own activity, paste the Hindi name, tag the themes, put the amount on the untied basic grant, upload before 31 March 2027. Do not collapse the file into one vague 'child welfare' line.",
    NEGATIVE_NOTE,
    FUND_NOTE,
    "Phases: P1 October 2026 start now; P2 October–December 2026 plan campaign; P3 approve and upload by 31 March 2027; P4 deliver April 2027–March 2028.",
    "Link column: Direct means the activity is the thing the indicator measures (a Bal Sabha, a VHND, an upload). Contributory means it supports the indicator but will not move the number by itself (a register, a wall, a kitchen garden).",
    "KAWACH, where the block coordinator is placed, can support facilitation. The lead on every line is a government post.",
  ];
  return [["Read me"], ...lines.map((line) => [line])];
}

const HEAD = [
  "ID",
  "Focus",
  "Activity (English)",
  "eGramSwaraj name (Hindi)",
  "Themes",
  "PAI indicator",
  "Direction",
  "Link to indicator",
  "Data source",
  "Block lead",
  "With",
  "Fund source",
  "Phase",
  "Timing",
  "Unit",
  "Unit cost (Rs)",
  "Qty",
  "Amount (Rs)",
  "In Rs 50000",
  "In Rs 1 lakh",
  "In Rs 2 lakh",
  "Booking note",
];

function activityRow(a: Activity): (string | number)[] {
  const inn = (amount: PackageAmount) => (activitiesIn(amount).some((x) => x.id === a.id) ? "Yes" : "");
  return [
    a.id,
    a.focus,
    a.en,
    a.hi,
    themeList(a),
    a.indicator,
    directionWord(a.direction),
    a.link,
    a.source,
    a.lead,
    a.with,
    a.fund,
    phaseText(a.phase),
    a.timing,
    a.unit,
    a.unitCost,
    a.qty,
    a.amount,
    inn(50000),
    inn(100000),
    inn(200000),
    a.basis,
  ];
}

export function catalogueRows(): (string | number)[][] {
  return [HEAD, ...ACTIVITIES.map(activityRow)];
}

export function packageRows(amount: PackageAmount): (string | number)[][] {
  const blur = PACKAGE_BLURB[amount];
  const lines = activitiesIn(amount);
  const rows: (string | number)[][] = [
    [blur.file],
    [blur.title],
    [blur.adds],
    [blur.refuses],
    [],
    ["ID", "Focus", "eGramSwaraj name (Hindi)", "Activity (English)", "Themes", "PAI indicator", "Direction", "Source", "Lead", "Fund", "Phase", "Unit", "Qty", "Rate (Rs)", "Amount (Rs)"],
  ];
  let focus = "";
  let sub = 0;
  for (const a of lines) {
    if (a.focus !== focus) {
      if (focus) rows.push(["", `Subtotal — ${focus}`, "", "", "", "", "", "", "", "", "", "", "", "", sub]);
      focus = a.focus;
      sub = 0;
    }
    sub += a.amount;
    rows.push([
      a.id,
      a.focus,
      a.hi,
      a.en,
      a.themes.map((t) => `T${t}`).join(", "),
      a.indicator,
      directionWord(a.direction),
      a.source,
      a.lead,
      a.fund,
      `${PHASES[a.phase].label} ${PHASES[a.phase].when}`,
      a.unit,
      a.qty,
      a.unitCost,
      a.amount,
    ]);
  }
  if (focus) rows.push(["", `Subtotal — ${focus}`, "", "", "", "", "", "", "", "", "", "", "", "", sub]);
  rows.push(["", "TOTAL — check against the file ceiling", "", "", "", "", "", "", "", "", "", "", "", "", packageTotal(amount)]);
  if (amount === 200000) {
    rows.push([]);
    rows.push(["Beside this file — do not add these amounts into the ₹2,00,000"]);
    for (const a of ACTIVITIES.filter((x) => x.tier === "conv" || x.tier === "capex")) {
      rows.push([a.id, tierLabel(a.tier), a.hi, a.en, a.themes.map((t) => `T${t}`).join(", "), a.indicator, a.fund]);
    }
  }
  return rows;
}

export function gpRows(): (string | number)[][] {
  const head = [
    "Priority (1 = weakest overall)",
    "Gram Panchayat",
    "Code",
    "Overall",
    "Overall grade",
    ...ALL_THEMES.flatMap((t) => [`T${t} score`, `T${t} grade`]),
    "Recommended file (Rs)",
    "Why",
    "Open these themes first",
    "First activities to paste",
  ];
  const body = rankedGps().map((gp) => {
    const rec = recommend(gp);
    const hot = hotThemes(gp);
    const first = firstActivities(gp);
    return [
      gp.priority,
      gp.name,
      gp.code,
      gp.overall.score,
      `${gp.overall.grade} ${gp.overall.band}`,
      ...ALL_THEMES.flatMap((t) => [gp.t[t].score, `${gp.t[t].grade} ${gp.t[t].band}`]),
      rec.amount,
      rec.reasons.join(" "),
      hot.map((t) => `T${t} ${THEME_OFFICIAL[t]} ${gp.t[t].score}`).join("; "),
      first.map((a) => `${a.id}. ${a.hi} (${a.amount})`).join(" | "),
    ];
  });
  return [
    ["Balumath block — 13 Gram Panchayats. PAI 2022-23. Recommended files sum to Rs " + blockEnvelope() + " if each GP adopts its file."],
    ["Themes 4 and 5 are Beginner in most GPs. Fund them from JJM and SBM-G, not from this child file."],
    [],
    head,
    ...body,
  ];
}

export function indicatorRows(): (string | number)[][] {
  const head = ["PAI indicator", "Direction", "Link", "Source", "Themes", "Activity IDs", "Reviewer on the quarterly scorecard"];
  const map = new Map<string, Activity[]>();
  for (const a of ACTIVITIES) {
    const list = map.get(a.indicator) ?? [];
    list.push(a);
    map.set(a.indicator, list);
  }
  const rows: (string | number)[][] = [head];
  for (const [indicator, list] of map) {
    const reviewer = SCORECARD.find((s) => s.indicator === indicator)?.reviewer ?? "";
    rows.push([
      indicator,
      directionWord(list[0].direction),
      [...new Set(list.map((a) => a.link))].join(", "),
      [...new Set(list.map((a) => a.source))].join(", "),
      [...new Set(list.flatMap((a) => a.themes))].map((t) => `T${t}`).join(", "),
      list.map((a) => a.id).join(", "),
      reviewer,
    ]);
  }
  rows.push([]);
  rows.push([
    "Companion, not a separate budget line: while activity 31 (pension camp) runs, also record persons with disabilities still waiting for an assistive device. Theme 7, GP-Entry. There is no rupee line for the device; the device is a departmental converge.",
  ]);
  rows.push([
    "Companion: activity 10 (re-enrolment) should be read with girls' transition, Theme 9, UDISE+, as well as the all-child transition rate.",
  ]);
  return rows;
}
