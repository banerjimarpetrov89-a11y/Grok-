import {
  ACTIVITIES,
  type Activity,
  type PackageAmount,
  type ThemeId,
  packageIncludes,
} from "./catalogue.ts";
import { inr } from "./format.ts";

export type Grade = "B" | "C" | "D";
export type Band = "Performer" | "Aspirant" | "Beginner";
export type AnyTheme = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export type Score = { score: number; grade: Grade; band: Band };

export type Gp = {
  name: string;
  code: string;
  overall: Score;
  t: Record<AnyTheme, Score>;
};

export const ALL_THEMES: AnyTheme[] = [1, 2, 3, 4, 5, 6, 7, 8, 9];

export const THEME_OFFICIAL: Record<AnyTheme, string> = {
  1: "Poverty Free and Enhanced Livelihoods Panchayat",
  2: "Healthy Panchayat",
  3: "Child Friendly Panchayat",
  4: "Water Sufficient Panchayat",
  5: "Clean and Green Panchayat",
  6: "Self-sufficient Infrastructure in Panchayat",
  7: "Socially Just and Socially Secured Panchayat",
  8: "Panchayat with Good Governance",
  9: "Women Friendly Panchayat",
};

function g(score: number, grade: Grade): Score {
  const band: Band = grade === "B" ? "Performer" : grade === "C" ? "Aspirant" : "Beginner";
  return { score, grade, band };
}

export const GPS: Gp[] = [
  {
    name: "Sheregara",
    code: "113986",
    overall: g(46.82, "C"),
    t: {
      1: g(55.29, "C"),
      2: g(66.67, "B"),
      3: g(46.16, "C"),
      4: g(44.34, "C"),
      5: g(30.54, "D"),
      6: g(34.87, "D"),
      7: g(54.92, "C"),
      8: g(41.62, "C"),
      9: g(58.89, "C"),
    },
  },
  {
    name: "Basiya",
    code: "113968",
    overall: g(46.31, "C"),
    t: {
      1: g(64.84, "B"),
      2: g(50, "C"),
      3: g(45.16, "C"),
      4: g(48.65, "C"),
      5: g(31.75, "D"),
      6: g(34.99, "D"),
      7: g(59.33, "C"),
      8: g(43.46, "C"),
      9: g(47.99, "C"),
    },
  },
  {
    name: "Ganeshpur",
    code: "113974",
    overall: g(45.03, "C"),
    t: {
      1: g(58.12, "C"),
      2: g(66.67, "B"),
      3: g(43.13, "C"),
      4: g(41.42, "C"),
      5: g(28.39, "D"),
      6: g(32.5, "D"),
      7: g(57.05, "C"),
      8: g(39.04, "D"),
      9: g(53.46, "C"),
    },
  },
  {
    name: "Masiyatu",
    code: "113979",
    overall: g(44.98, "C"),
    t: {
      1: g(55.98, "C"),
      2: g(66.67, "B"),
      3: g(44.45, "C"),
      4: g(41.06, "C"),
      5: g(28.36, "D"),
      6: g(33.96, "D"),
      7: g(51.17, "C"),
      8: g(39.83, "D"),
      9: g(56.41, "C"),
    },
  },
  {
    name: "Chetag",
    code: "113970",
    overall: g(44.41, "C"),
    t: {
      1: g(58.86, "C"),
      2: g(57.6, "C"),
      3: g(43.12, "C"),
      4: g(39.99, "D"),
      5: g(30.85, "D"),
      6: g(31.98, "D"),
      7: g(54.61, "C"),
      8: g(39.05, "D"),
      9: g(54.6, "C"),
    },
  },
  {
    name: "Balu",
    code: "113964",
    overall: g(44.3, "C"),
    t: {
      1: g(57.24, "C"),
      2: g(69.09, "B"),
      3: g(40.46, "C"),
      4: g(40.9, "C"),
      5: g(24.67, "D"),
      6: g(33.45, "D"),
      7: g(53.93, "C"),
      8: g(41.83, "C"),
      9: g(53.98, "C"),
    },
  },
  {
    name: "Marang Loiya",
    code: "113978",
    overall: g(44.3, "C"),
    t: {
      1: g(53.99, "C"),
      2: g(66.67, "B"),
      3: g(41.6, "C"),
      4: g(40.06, "C"),
      5: g(30.42, "D"),
      6: g(33.71, "D"),
      7: g(53.08, "C"),
      8: g(38.06, "D"),
      9: g(52.86, "C"),
    },
  },
  {
    name: "Bhageya",
    code: "113969",
    overall: g(42.95, "C"),
    t: {
      1: g(48.75, "C"),
      2: g(66.67, "B"),
      3: g(41.97, "C"),
      4: g(40.02, "C"),
      5: g(32.04, "D"),
      6: g(29.11, "D"),
      7: g(50.67, "C"),
      8: g(37.94, "D"),
      9: g(50.77, "C"),
    },
  },
  {
    name: "Murpa",
    code: "113980",
    overall: g(42.16, "C"),
    t: {
      1: g(49.93, "C"),
      2: g(66.67, "B"),
      3: g(42.9, "C"),
      4: g(32.73, "D"),
      5: g(28.96, "D"),
      6: g(32.46, "D"),
      7: g(51.55, "C"),
      8: g(37.95, "D"),
      9: g(49, "C"),
    },
  },
  {
    name: "Dhadhu",
    code: "113973",
    overall: g(41.87, "C"),
    t: {
      1: g(51.98, "C"),
      2: g(66.67, "B"),
      3: g(40.16, "C"),
      4: g(38.06, "D"),
      5: g(25.89, "D"),
      6: g(28.64, "D"),
      7: g(53.07, "C"),
      8: g(39.99, "D"),
      9: g(47.48, "C"),
    },
  },
  {
    name: "Rajvar",
    code: "113982",
    overall: g(41.74, "C"),
    t: {
      1: g(44.78, "C"),
      2: g(66.67, "B"),
      3: g(41.77, "C"),
      4: g(33.7, "D"),
      5: g(30, "D"),
      6: g(32.38, "D"),
      7: g(47.8, "C"),
      8: g(39.67, "D"),
      9: g(49.69, "C"),
    },
  },
  {
    name: "Jhabar",
    code: "113977",
    overall: g(41.49, "C"),
    t: {
      1: g(44.32, "C"),
      2: g(66.15, "B"),
      3: g(40.47, "C"),
      4: g(34.38, "D"),
      5: g(35.49, "D"),
      6: g(31.13, "D"),
      7: g(49.37, "C"),
      8: g(39.66, "D"),
      9: g(41.26, "C"),
    },
  },
  {
    name: "Balumath",
    code: "113966",
    overall: g(38.89, "D"),
    t: {
      1: g(48.08, "C"),
      2: g(66.67, "B"),
      3: g(41.08, "C"),
      4: g(31.12, "D"),
      5: g(20.03, "D"),
      6: g(36.82, "D"),
      7: g(48.25, "C"),
      8: g(36.39, "D"),
      9: g(38.33, "D"),
    },
  },
];

export type Rec = { amount: 100000 | 200000; reasons: string[] };

export function recommend(gp: Gp): Rec {
  const reasons: string[] = [];
  if (gp.overall.grade === "D") {
    reasons.push("Overall PAI is Beginner — the only such GP in the block.");
  }
  if (gp.t[9].grade === "D" || gp.t[9].score < 45) {
    reasons.push(
      `Theme 9 is ${gp.t[9].score} (${gp.t[9].band}) — child marriage, Mahila Sabha and girls' retention need the full file.`,
    );
  }
  if (gp.t[6].score < 32) {
    reasons.push(`Theme 6 is ${gp.t[6].score} — child-serving facilities are a severe gap.`);
  }
  if (gp.t[8].score < 39) {
    reasons.push(`Theme 8 is ${gp.t[8].score} — Sabha, grievance and plan upload are behind.`);
  }
  if (gp.t[3].score < 41.5) {
    reasons.push(`Theme 3 is ${gp.t[3].score} — the child-friendly score is in the bottom of the block.`);
  }
  if (gp.t[7].score < 50) {
    reasons.push(
      `Theme 7 is ${gp.t[7].score} — the pension camp and the vulnerable-family lines should not be left out.`,
    );
  }
  if (reasons.length > 0) return { amount: 200000, reasons };
  const hold: string[] = [];
  if (gp.t[2].grade !== "B") {
    hold.push(
      `Theme 2 is ${gp.t[2].score} (${gp.t[2].band}), behind the rest of the block. The ₹1 lakh file keeps health, ICDS and nutrition. The ₹50,000 file drops them.`,
    );
  }
  hold.push(
    "Theme 6 is Beginner here, as in every GP of Balumath. The ₹50,000 file has no facility line — use it only if the untied balance cannot reach ₹1 lakh.",
  );
  return { amount: 100000, reasons: hold };
}

const TARGET: ThemeId[] = [2, 3, 6, 7, 8, 9];

export function hotThemes(gp: Gp): ThemeId[] {
  const beginners = TARGET.filter((id) => gp.t[id].grade === "D").sort(
    (a, b) => gp.t[a].score - gp.t[b].score,
  );
  const rest = TARGET.filter((id) => !beginners.includes(id)).sort(
    (a, b) => gp.t[a].score - gp.t[b].score,
  );
  return [...beginners, ...rest].slice(0, Math.max(2, beginners.length));
}

export function firstActivities(gp: Gp): Activity[] {
  const rec = recommend(gp);
  const hot = new Set(hotThemes(gp));
  return ACTIVITIES.filter(
    (a) => packageIncludes(a, rec.amount) && a.themes.some((t) => hot.has(t)),
  )
    .sort((a, b) => {
      const ah = a.themes.filter((t) => hot.has(t)).length;
      const bh = b.themes.filter((t) => hot.has(t)).length;
      return bh - ah || b.amount - a.amount || a.id - b.id;
    })
    .slice(0, 6);
}

export function rankedGps(): (Gp & { priority: number })[] {
  return [...GPS]
    .sort((a, b) => a.overall.score - b.overall.score || a.name.localeCompare(b.name))
    .map((gp, i) => ({ ...gp, priority: i + 1 }));
}

export function blockEnvelope(): number {
  return GPS.reduce((sum, gp) => sum + recommend(gp).amount, 0);
}

export function resolution(gp: Gp): string {
  const rec = recommend(gp);
  const hot = hotThemes(gp)
    .map((id) => `Theme ${id} (${THEME_OFFICIAL[id]})`)
    .join("; ");
  return [
    `Resolution of the Gram Sabha of ${gp.name} Gram Panchayat (code ${gp.code}), Block Balumath, District Latehar.`,
    ``,
    `The Gram Sabha resolves to include a child-friendly package of ${inr(rec.amount)} in the GPDP for 2027-28. The lines are the ${inr(rec.amount)} file of the Balumath GPDP Child Protection Activity Catalogue. Priority themes for this GP: ${hot}.`,
    ``,
    `The amount will be met from the untied basic grant / GPDP untied fund. Vaccines, IFA, ORS and take-home ration continue from NHM and ICDS. Pensions continue from NSAP or the state scheme. A new Anganwadi building or new school building, if sanctioned, will be booked on VB–G RAM G Schedule I and not inside this amount.`,
    ``,
    `The Panchayat Sachiv will enter each activity on eGramSwaraj against the theme in the catalogue and upload the approved plan before 31 March 2027. The Village Child Protection Committee will keep the evidence file for the next PAI.`,
  ].join("\n");
}

export function activityListText(amount: PackageAmount, gpName?: string): string {
  const lines = ACTIVITIES.filter((a) => packageIncludes(a, amount));
  const head = gpName
    ? `${gpName} Gram Panchayat — child-friendly GPDP lines, ${inr(amount)}`
    : `Child-friendly GPDP lines, one GP, ${inr(amount)}`;
  const body = lines
    .map(
      (a, i) =>
        `${i + 1}. ${a.hi} — ${inr(a.amount)} (Theme ${a.themes.join(", ")})`,
    )
    .join("\n");
  const total = lines.reduce((s, a) => s + a.amount, 0);
  return `${head}\n\n${body}\n\nTotal ${inr(total)}\nFund: GPDP untied / 15th FC basic grant. Not VB–G RAM G wages.`;
}

function assertGps(): void {
  if (GPS.length !== 13) throw new Error(`Expected 13 GPs, found ${GPS.length}`);
  const oneLakh = GPS.filter((gp) => recommend(gp).amount === 100000).map((gp) => gp.name);
  const expected = ["Sheregara", "Basiya", "Ganeshpur", "Masiyatu"];
  if (oneLakh.slice().sort().join() !== expected.slice().sort().join()) {
    throw new Error(`₹1 lakh GPs changed: ${oneLakh.join(", ")}`);
  }
  if (blockEnvelope() !== 2200000) throw new Error(`Block envelope is ${blockEnvelope()}`);
}

assertGps();
