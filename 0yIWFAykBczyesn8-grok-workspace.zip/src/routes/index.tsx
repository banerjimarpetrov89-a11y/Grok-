import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ACTIVITIES } from "@/lib/catalogue";
import { GPS, blockEnvelope } from "@/lib/gps";
import { inr } from "@/lib/format";
import { CatalogueView } from "@/components/catalogue-view";
import { PackageView } from "@/components/package-view";
import { GpView } from "@/components/gp-view";
import { EnterView } from "@/components/enter-view";

export const Route = createFileRoute("/")({ component: Home });

type Sheet = "catalogue" | "50" | "100" | "200" | "gp" | "enter";

const TABS: { id: Sheet; label: string }[] = [
  { id: "catalogue", label: "Catalogue" },
  { id: "50", label: "₹50,000" },
  { id: "100", label: "₹1 lakh" },
  { id: "200", label: "₹2 lakh" },
  { id: "gp", label: "13 GPs" },
  { id: "enter", label: "How to enter" },
];

function Home() {
  const [sheet, setSheet] = useState<Sheet>("catalogue");
  return (
    <div className="min-h-screen bg-bg text-ink">
      <header className="border-b border-line bg-ink text-surface">
        <div className="mx-auto flex max-w-screen-xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-semibold tracking-wide text-primary-fg uppercase">
              Latehar district · Balumath block · PAI 2022-23
            </p>
            <h1 className="mt-1 font-serif text-2xl font-semibold tracking-tight sm:text-3xl">
              GPDP Child Protection Activity Catalogue
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-surface">
              {ACTIVITIES.length} activities for child protection, health, ICDS, mothers, nutrition and IEC,
              mapped to Themes 2, 3, 6, 7, 8 and 9. Three files a Gram Panchayat can adopt as they stand.
            </p>
            <p className="mt-2 text-sm text-surface">
              {GPS.length} GPs · recommended block envelope {inr(blockEnvelope())}
            </p>
          </div>
          <a
            href="/Balumath-GPDP-Child-Protection-Catalogue.xlsx"
            download
            className="no-print inline-flex min-h-11 items-center justify-center bg-primary px-4 text-sm font-semibold text-primary-fg"
          >
            Download Excel workbook
          </a>
        </div>
      </header>
      <div className="mx-auto max-w-screen-xl">
        <nav className="no-print sticky top-0 z-20 border-b border-line bg-bg" aria-label="Workbook sheets">
          <div className="flex gap-1 overflow-x-auto px-2 pt-2" role="tablist">
            {TABS.map((tab) => {
              const on = sheet === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  className={
                    on
                      ? "min-h-11 shrink-0 border border-b-0 border-line bg-surface px-3 text-sm font-semibold text-ink"
                      : "min-h-11 shrink-0 px-3 text-sm font-semibold text-muted"
                  }
                  onClick={() => setSheet(tab.id)}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </nav>
        <div className="border-x border-b border-line bg-surface" role="tabpanel">
          {sheet === "catalogue" ? <CatalogueView /> : null}
          {sheet === "50" ? <PackageView amount={50000} /> : null}
          {sheet === "100" ? <PackageView amount={100000} /> : null}
          {sheet === "200" ? <PackageView amount={200000} /> : null}
          {sheet === "gp" ? (
            <GpView
              onOpen={(amount) => setSheet(amount === 100000 ? "100" : "200")}
            />
          ) : null}
          {sheet === "enter" ? <EnterView /> : null}
        </div>
        <footer className="px-4 py-6 text-sm text-muted">
          One Gram Panchayat, one year. Amounts are untied-fund ceilings, not estimates under VB–G RAM G.
          Activity leads are block posts. Confirm dates with the District Panchayat Raj Officer.
        </footer>
      </div>
    </div>
  );
}
