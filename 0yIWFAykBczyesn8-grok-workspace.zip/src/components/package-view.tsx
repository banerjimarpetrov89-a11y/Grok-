import { Fragment, useState } from "react";
import {
  ACTIVITIES,
  FOCI,
  PACKAGE_BLURB,
  type Activity,
  type Focus,
  type PackageAmount,
  activitiesIn,
  packageTotal,
} from "@/lib/catalogue";
import { activityListText } from "@/lib/gps";
import { inr } from "@/lib/format";
import { Booking, Themes } from "@/components/bits";
import { CopyButton } from "@/components/copy-button";

export function PackageView({ amount }: { amount: PackageAmount }) {
  const blur = PACKAGE_BLURB[amount];
  const lines = activitiesIn(amount);
  const [open, setOpen] = useState<number | null>(null);
  const groups = FOCI.map((focus) => ({
    focus,
    rows: lines.filter((a) => a.focus === focus),
  })).filter((g) => g.rows.length > 0);

  return (
    <div>
      <header className="border-b border-line px-3 py-4 sm:px-4">
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">{blur.file}</p>
        <h2 className="mt-1 font-serif text-2xl font-semibold tracking-tight">{blur.title}</h2>
        <p className="mt-2 max-w-3xl text-sm">{blur.adds}</p>
        <p className="mt-2 max-w-3xl text-sm text-accent">{blur.refuses}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <CopyButton text={activityListText(amount)} label="Copy Hindi list" />
          <a
            href="/Balumath-GPDP-Child-Protection-Catalogue.xlsx"
            download
            className="inline-flex min-h-11 items-center bg-primary px-3 text-sm font-semibold text-primary-fg"
          >
            Excel workbook
          </a>
        </div>
      </header>
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="bg-ink text-left text-surface">
              <th className="px-2 py-2 font-semibold">#</th>
              <th className="px-2 py-2 font-semibold">Activity</th>
              <th className="px-2 py-2 font-semibold">Themes</th>
              <th className="px-2 py-2 font-semibold">PAI indicator</th>
              <th className="px-2 py-2 text-right font-semibold">Qty</th>
              <th className="px-2 py-2 text-right font-semibold">Rate</th>
              <th className="px-2 py-2 text-right font-semibold">Amount</th>
            </tr>
          </thead>
          <tbody>
            {groups.map((g) => (
              <Group key={g.focus} focus={g.focus} rows={g.rows} open={open} setOpen={setOpen} />
            ))}
            <tr className="border-t-4 border-ink bg-bg">
              <td colSpan={6} className="px-2 py-3 font-serif text-lg font-semibold">
                Total — must equal {inr(amount)}
              </td>
              <td className="px-2 py-3 text-right font-serif text-lg font-semibold tabular-nums">
                {inr(packageTotal(amount))}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="md:hidden">
        {groups.map((g) => (
          <section key={g.focus}>
            <h3 className="bg-bg px-3 py-2 text-sm font-semibold">{g.focus}</h3>
            <ul>
              {g.rows.map((a) => (
                <li key={a.id} className="border-b border-line p-3">
                  <div className="flex items-baseline justify-between gap-3">
                    <p className="text-xs font-semibold text-muted">{a.id}</p>
                    <p className="font-semibold tabular-nums">{inr(a.amount)}</p>
                  </div>
                  <button
                    type="button"
                    className="mt-1 text-left font-semibold"
                    aria-expanded={open === a.id}
                    onClick={() => setOpen(open === a.id ? null : a.id)}
                  >
                    {a.en}
                  </button>
                  <p className="mt-1 text-sm text-muted">
                    {a.qty} {a.unit} × {inr(a.unitCost)}
                  </p>
                  <div className="mt-2">
                    <Themes ids={a.themes} />
                  </div>
                  {open === a.id ? (
                    <div className="mt-3 border-t border-line pt-3">
                      <Booking a={a} />
                    </div>
                  ) : null}
                </li>
              ))}
            </ul>
            <p className="flex justify-between border-b border-line px-3 py-2 text-sm font-semibold">
              <span>Subtotal</span>
              <span className="tabular-nums">{inr(g.rows.reduce((s, a) => s + a.amount, 0))}</span>
            </p>
          </section>
        ))}
        <p className="flex items-baseline justify-between px-3 py-4 font-serif text-xl font-semibold">
          <span>Total</span>
          <span className="tabular-nums">{inr(packageTotal(amount))}</span>
        </p>
      </div>
      {amount === 200000 ? (
        <aside className="border-t border-line px-3 py-4 sm:px-4">
          <h3 className="font-serif text-lg font-semibold">Beside this file — not inside the ₹2,00,000</h3>
          <ul className="mt-3 grid gap-3">
            {ACTIVITIES.filter((a) => a.tier === "conv" || a.tier === "capex").map((a) => (
              <li key={a.id} className="border border-line p-3 text-sm">
                <p className="text-xs font-semibold text-muted">
                  {a.id} · {a.tier === "capex" ? "Capital" : "Convergence"} · ₹0 in this file
                </p>
                <p className="mt-1 font-semibold">{a.en}</p>
                <p lang="hi" className="mt-1 text-muted">
                  {a.hi}
                </p>
                <p className="mt-2">{a.fund}</p>
              </li>
            ))}
          </ul>
        </aside>
      ) : null}
    </div>
  );
}

function Group({
  focus,
  rows,
  open,
  setOpen,
}: {
  focus: Focus;
  rows: Activity[];
  open: number | null;
  setOpen: (id: number | null) => void;
}) {
  const sub = rows.reduce((s, a) => s + a.amount, 0);
  return (
    <Fragment>
      <tr className="bg-bg">
        <td colSpan={7} className="px-2 py-2 text-xs font-semibold tracking-wide text-muted uppercase">
          {focus}
        </td>
      </tr>
      {rows.map((a) => (
        <Fragment key={a.id}>
          <tr className="border-b border-line">
            <td className="px-2 py-2 align-top font-semibold tabular-nums">{a.id}</td>
            <td className="px-2 py-2 align-top">
              <button
                type="button"
                className="text-left font-semibold"
                aria-expanded={open === a.id}
                onClick={() => setOpen(open === a.id ? null : a.id)}
              >
                {a.en}
              </button>
            </td>
            <td className="px-2 py-2 align-top">
              <Themes ids={a.themes} />
            </td>
            <td className="px-2 py-2 align-top">{a.indicator}</td>
            <td className="px-2 py-2 text-right align-top tabular-nums">
              {a.qty} {a.unit}
            </td>
            <td className="px-2 py-2 text-right align-top tabular-nums">{inr(a.unitCost)}</td>
            <td className="px-2 py-2 text-right align-top font-semibold tabular-nums">{inr(a.amount)}</td>
          </tr>
          {open === a.id ? (
            <tr className="border-b border-line bg-bg">
              <td colSpan={7} className="px-3 py-3">
                <Booking a={a} />
              </td>
            </tr>
          ) : null}
        </Fragment>
      ))}
      <tr className="border-b border-ink">
        <td colSpan={6} className="px-2 py-2 text-right text-sm font-semibold">
          Subtotal
        </td>
        <td className="px-2 py-2 text-right font-semibold tabular-nums">{inr(sub)}</td>
      </tr>
    </Fragment>
  );
}
