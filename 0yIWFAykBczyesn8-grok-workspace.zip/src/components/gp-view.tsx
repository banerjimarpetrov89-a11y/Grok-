import { useState } from "react";
import { TARGET, THEME_SHORT, type ThemeId } from "@/lib/catalogue";
import { activityListText, blockEnvelope, firstActivities, hotThemes, rankedGps, recommend, resolution, type Gp } from "@/lib/gps";
import { inr, num } from "@/lib/format";
import { GradePill } from "@/components/bits";
import { CopyButton } from "@/components/copy-button";

export function GpView({ onOpen }: { onOpen: (amount: 100000 | 200000) => void }) {
  const ranked = rankedGps();
  const [openCode, setOpenCode] = useState<string | null>(ranked[0]?.code ?? null);
  const twoLakh = ranked.filter((gp) => recommend(gp).amount === 200000).length;
  const oneLakh = ranked.length - twoLakh;
  return (
    <div>
      <header className="border-b border-line px-3 py-4 sm:px-4">
        <h2 className="font-serif text-2xl font-semibold tracking-tight">Which file for which GP</h2>
        <p className="mt-2 max-w-3xl text-sm">
          Sorted with the weakest overall PAI first. Theme 6 is Beginner in all 13 GPs. Theme 2 is already
          Performer in 11 — hold it, and do not trade it away. Theme 9 is Beginner only in Balumath GP.
        </p>
        <p className="mt-2 max-w-3xl text-sm">
          {twoLakh} GPs at {inr(200000)}, {oneLakh} GPs at {inr(100000)}. If each adopts the recommendation,
          the block books <span className="font-semibold">{inr(blockEnvelope())}</span> of child-development
          lines. Themes 4 and 5 are also Beginner in most of these GPs — fund them from JJM and SBM-G, not by
          raiding this file.
        </p>
        <p className="mt-2 max-w-3xl text-sm text-muted">
          Scores are the 2022-23 PAI sheet. Replace them when a later round is available; the rule is on the
          How to enter sheet.
        </p>
      </header>
      {ranked.map((gp) => (
        <GpRow
          key={gp.code}
          gp={gp}
          onOpen={onOpen}
          open={openCode === gp.code}
          onToggle={(next) =>
            setOpenCode((cur) => (next ? gp.code : cur === gp.code ? null : cur))
          }
        />
      ))}
    </div>
  );
}

function GpRow({
  gp,
  onOpen,
  open,
  onToggle,
}: {
  gp: Gp & { priority: number };
  onOpen: (amount: 100000 | 200000) => void;
  open: boolean;
  onToggle: (next: boolean) => void;
}) {
  const rec = recommend(gp);
  const hot = hotThemes(gp);
  const first = firstActivities(gp);
  return (
    <details
      className="group border-b border-line"
      open={open}
      onToggle={(e) => onToggle(e.currentTarget.open)}
    >
      <summary className="flex cursor-pointer flex-wrap items-baseline justify-between gap-2 px-3 py-3 sm:px-4">
        <span className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <span className="text-xs font-semibold text-muted tabular-nums">#{gp.priority}</span>
          <span className="font-serif text-lg font-semibold">{gp.name}</span>
          <span className="text-sm text-muted">{gp.code}</span>
          <GradePill grade={gp.overall.grade} band={gp.overall.band} />
          <span className="text-sm tabular-nums">{num(gp.overall.score)}</span>
        </span>
        <span className="font-semibold tabular-nums">{inr(rec.amount)}</span>
      </summary>
      <div className="grid gap-4 px-3 pb-4 sm:px-4">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {TARGET.map((id) => (
            <ThemeBar key={id} id={id} score={gp.t[id].score} grade={gp.t[id].grade} band={gp.t[id].band} hot={hot.includes(id)} />
          ))}
        </div>
        <div>
          <h3 className="text-sm font-semibold">Why this file</h3>
          <ul className="mt-1 list-disc pl-5 text-sm">
            {rec.reasons.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-semibold">Open these lines first</h3>
          <ul className="mt-2 grid gap-2">
            {first.map((a) => (
              <li key={a.id} className="border border-line px-3 py-2 text-sm">
                <div className="flex items-baseline justify-between gap-3">
                  <span className="font-semibold">
                    {a.id}. {a.hi}
                  </span>
                  <span className="shrink-0 tabular-nums">{inr(a.amount)}</span>
                </div>
                <p className="mt-1 text-muted">{a.indicator}</p>
              </li>
            ))}
          </ul>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className="inline-flex min-h-11 items-center bg-primary px-3 text-sm font-semibold text-primary-fg"
            onClick={() => onOpen(rec.amount)}
          >
            Open the {inr(rec.amount)} file
          </button>
          <CopyButton text={resolution(gp)} label="Copy Gram Sabha resolution" />
          <CopyButton text={activityListText(rec.amount, gp.name)} label="Copy activity list" />
        </div>
        <pre className="overflow-x-auto border border-line bg-bg p-3 text-sm leading-relaxed whitespace-pre-wrap">
          {resolution(gp)}
        </pre>
      </div>
    </details>
  );
}

function ThemeBar({
  id,
  score,
  grade,
  band,
  hot,
}: {
  id: ThemeId;
  score: number;
  grade: "B" | "C" | "D";
  band: string;
  hot: boolean;
}) {
  return (
    <div className={hot ? "border border-ink p-2" : "border border-line p-2"}>
      <div className="flex items-baseline justify-between gap-2">
        <p className="text-sm font-semibold">
          T{id} {THEME_SHORT[id]}
        </p>
        <p className="text-sm tabular-nums">{num(score)}</p>
      </div>
      <div className="mt-2 h-2 bg-line">
        <div
          className={grade === "D" ? "h-2 bg-accent" : "h-2 bg-primary"}
          style={{ width: `${Math.max(0, Math.min(100, score))}%` }}
        />
      </div>
      <div className="mt-2">
        <GradePill grade={grade} band={band} />
        {hot ? <span className="ml-2 text-xs font-semibold">Open first</span> : null}
      </div>
    </div>
  );
}
