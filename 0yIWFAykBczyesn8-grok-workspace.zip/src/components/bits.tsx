import type { ThemeId } from "@/lib/catalogue";
import { directionWord, phaseText, type Activity, type Direction } from "@/lib/catalogue";
import type { Grade } from "@/lib/gps";

export function Themes({ ids }: { ids: ThemeId[] }) {
  return (
    <span className="inline-flex flex-wrap gap-1">
      {ids.map((id) => (
        <span
          key={id}
          className="border border-line bg-bg px-1.5 py-0.5 text-xs font-semibold tracking-wide text-ink"
        >
          T{id}
        </span>
      ))}
    </span>
  );
}

export function GradePill({ grade, band }: { grade: Grade | string; band: string }) {
  const cls =
    grade === "D"
      ? "bg-accent text-accent-fg"
      : grade === "B"
        ? "bg-primary text-primary-fg"
        : "border border-line bg-surface text-ink";
  return (
    <span className={`inline-flex items-center rounded-sm px-1.5 py-0.5 text-xs font-semibold ${cls}`}>
      {grade} · {band}
    </span>
  );
}

export function DirectionMark({ direction }: { direction: Direction }) {
  return (
    <span className={direction === "Negative" ? "font-semibold text-accent" : "font-semibold text-primary"}>
      {directionWord(direction)}
    </span>
  );
}

export function Booking({ a }: { a: Activity }) {
  return (
    <div className="grid gap-4 text-sm sm:grid-cols-2">
      <div>
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Paste into eGramSwaraj</p>
        <p lang="hi" className="mt-1 text-base leading-snug">
          {a.hi}
        </p>
      </div>
      <div>
        <p className="text-xs font-semibold tracking-wide text-muted uppercase">Booking note</p>
        <p className="mt-1">{a.basis}</p>
      </div>
      <p>
        <span className="font-semibold">Lead. </span>
        {a.lead}
        <span className="text-muted"> with {a.with}</span>
      </p>
      <p>
        <span className="font-semibold">Fund. </span>
        {a.fund}
      </p>
      <p>
        <span className="font-semibold">When. </span>
        {phaseText(a.phase)} — {a.timing}
      </p>
      <p>
        <span className="font-semibold">Indicator. </span>
        <DirectionMark direction={a.direction} />
        <span className="text-muted"> · {a.link} · {a.source}. </span>
        {a.indicator}
      </p>
    </div>
  );
}
