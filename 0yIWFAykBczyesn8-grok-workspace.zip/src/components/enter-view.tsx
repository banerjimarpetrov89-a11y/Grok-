import {
  ACTIVITIES,
  FUND_NOTE,
  NEGATIVE_NOTE,
  PHASES,
  SCORECARD,
  TARGET,
  THEME_NAME,
  directionWord,
  type PhaseId,
} from "@/lib/catalogue";
import { CopyButton } from "@/components/copy-button";

const STEPS = [
  "Open the Gram Panchayat’s GPDP for 2027-28 on eGramSwaraj. Do this during the people’s plan campaign, not after the upload deadline.",
  "On the GP sheet, take the recommended file. ₹50,000 is only a fallback if the untied balance cannot reach ₹1 lakh — record which lines are deferred.",
  "Enter each activity as its own line. Paste the Hindi name. Do not merge the file into one ‘child welfare’ activity.",
  "Tag the themes shown on the line. A line can sit on more than one theme; the indicator column is the one the quarterly review will watch.",
  "Put the rupee amount on the untied basic grant / GPDP untied fund. Leave NHM drugs, ICDS ration, pensions and new buildings off this amount.",
  "Where the link says Contributory, still enter the activity, and do not expect the PAI number to jump from that line alone.",
  "Upload the approved plan before 31 March 2027. Activity 35 exists so this step has a name and a small cost.",
  "Keep the evidence file (activity 13): minutes, the child-protection register, VHND sheets, and photographs of the walls.",
];

export function EnterView() {
  const byIndicator = new Map<string, number[]>();
  for (const a of ACTIVITIES) {
    const list = byIndicator.get(a.indicator) ?? [];
    list.push(a.id);
    byIndicator.set(a.indicator, list);
  }
  return (
    <div className="grid gap-8 px-3 py-4 sm:px-4">
      <section className="max-w-3xl">
        <h2 className="font-serif text-2xl font-semibold tracking-tight">How a Sachiv enters this</h2>
        <p className="mt-2 text-sm text-muted">
          Prepared for the FY 2027-28 campaign. The catalogue is the activity master. The three files are
          ready budgets. The GP sheet says which file, using the 2022-23 PAI baseline.
        </p>
        <ol className="mt-4 grid list-decimal gap-3 pl-5 text-sm">
          {STEPS.map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ol>
      </section>
      <section className="max-w-3xl border border-accent bg-surface p-3">
        <h3 className="font-serif text-lg font-semibold text-accent">Negative indicators</h3>
        <p className="mt-2 text-sm">{NEGATIVE_NOTE}</p>
      </section>
      <section>
        <h3 className="font-serif text-lg font-semibold">Phases</h3>
        <dl className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {(Object.keys(PHASES) as PhaseId[]).map((id) => (
            <div key={id} className="border border-line p-3">
              <dt className="font-semibold">
                {PHASES[id].label} · {PHASES[id].name}
              </dt>
              <dd className="text-sm text-muted">{PHASES[id].when}</dd>
            </div>
          ))}
        </dl>
      </section>
      <section>
        <h3 className="font-serif text-lg font-semibold">Themes this catalogue will move</h3>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {TARGET.map((id) => (
            <li key={id} className="border border-line p-3 text-sm">
              <span className="font-semibold">Theme {id}. </span>
              {THEME_NAME[id]}
              <p className="mt-1 text-muted">
                {ACTIVITIES.filter((a) => a.themes.includes(id)).length} activities
              </p>
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h3 className="font-serif text-lg font-semibold">Quarterly scorecard</h3>
        <p className="mt-2 max-w-3xl text-sm text-muted">
          Review these. They are the PAI lines the activities are written against. While the pension camp
          (activity 31) runs, also note persons with disabilities still waiting for an assistive device —
          Theme 7, GP-Entry — even though the device itself is not a rupee line here. Read re-enrolment
          (activity 10) with girls’ transition as well as the all-child rate.
        </p>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="bg-ink text-left text-surface">
                <th className="px-2 py-2 font-semibold">Indicator</th>
                <th className="px-2 py-2 font-semibold">Direction</th>
                <th className="px-2 py-2 font-semibold">Activities</th>
                <th className="px-2 py-2 font-semibold">Reviewed by</th>
              </tr>
            </thead>
            <tbody>
              {SCORECARD.map((row) => {
                const sample = ACTIVITIES.find((a) => a.indicator === row.indicator);
                return (
                  <tr key={row.indicator} className="border-b border-line align-top">
                    <td className="px-2 py-2">{row.indicator}</td>
                    <td className="px-2 py-2">{sample ? directionWord(sample.direction) : ""}</td>
                    <td className="px-2 py-2 tabular-nums">{(byIndicator.get(row.indicator) ?? []).join(", ")}</td>
                    <td className="px-2 py-2">{row.reviewer}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
      <section className="max-w-3xl">
        <h3 className="font-serif text-lg font-semibold">Fund rule</h3>
        <p className="mt-2 text-sm">{FUND_NOTE}</p>
      </section>
      <section className="max-w-3xl">
        <h3 className="font-serif text-lg font-semibold">Rule for the recommended file</h3>
        <ul className="mt-2 list-disc pl-5 text-sm">
          <li>₹2,00,000 if overall PAI is Beginner, or Theme 9 is under 45, or Theme 6 is under 32, or Theme 8 is under 39, or Theme 3 is under 41.5, or Theme 7 is under 50.</li>
          <li>Otherwise ₹1,00,000. On the 2022-23 sheet that is Sheregara, Basiya, Ganeshpur and Masiyatu.</li>
          <li>₹50,000 only if the balance is short. Say so in the resolution, and name the deferred lines.</li>
          <li>Health is a relative strength. Keep the VHND and immunisation lines anyway — they protect a Performer score. In Basiya and Chetag, Theme 2 is not yet Performer, so those lines are not optional.</li>
        </ul>
        <div className="mt-3">
          <CopyButton
            text="The Gram Sabha resolves to adopt the Balumath GPDP Child Protection Activity Catalogue file marked for this Gram Panchayat, to enter each line separately on eGramSwaraj under the theme indicated, to meet the cost from the untied basic grant, and to upload the plan before 31 March 2027. Commodities and new buildings will be converged, not paid from this amount."
            label="Copy a short resolution"
          />
        </div>
      </section>
    </div>
  );
}
