import { Fragment, useMemo, useState } from "react";
import {
  ACTIVITIES,
  FOCI,
  TARGET,
  PHASES,
  tierLabel,
  type PhaseId,
  type ThemeId,
  type Tier,
} from "@/lib/catalogue";
import { inr } from "@/lib/format";
import { Booking, Themes } from "@/components/bits";

const TIERS: { id: Tier | "all"; label: string }[] = [
  { id: "all", label: "All files" },
  { id: "50", label: "All three budgets" },
  { id: "100", label: "From ₹1 lakh" },
  { id: "200", label: "₹2 lakh only" },
  { id: "conv", label: "Convergence" },
  { id: "capex", label: "Capital" },
];

export function CatalogueView() {
  const [q, setQ] = useState("");
  const [theme, setTheme] = useState<"all" | ThemeId>("all");
  const [focus, setFocus] = useState<string>("all");
  const [tier, setTier] = useState<Tier | "all">("all");
  const [phase, setPhase] = useState<PhaseId | "all">("all");
  const [open, setOpen] = useState<number | null>(null);

  const rows = useMemo(() => {
    const query = q.trim().toLowerCase();
    return ACTIVITIES.filter((a) => {
      if (theme !== "all" && !a.themes.includes(theme)) return false;
      if (focus !== "all" && a.focus !== focus) return false;
      if (tier !== "all" && a.tier !== tier) return false;
      if (phase !== "all" && a.phase !== phase) return false;
      if (!query) return true;
      const blob = `${a.id} ${a.focus} ${a.en} ${a.hi} ${a.indicator} ${a.lead} ${a.fund} ${a.source}`.toLowerCase();
      return blob.includes(query);
    });
  }, [q, theme, focus, tier, phase]);

  const amount = rows.reduce((s, a) => s + a.amount, 0);

  return (
    <div>
      <div className="grid gap-2 border-b border-line p-3 sm:grid-cols-2 lg:grid-cols-6">
        <label className="flex flex-col gap-1 text-xs font-semibold text-muted sm:col-span-2">
          Search
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Activity, indicator, fund, Hindi name"
            className="min-h-11 border border-line bg-surface px-3 text-base text-ink md:text-sm"
          />
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-muted">
          Theme
          <select
            value={theme}
            onChange={(e) => setTheme(e.target.value === "all" ? "all" : (Number(e.target.value) as ThemeId))}
            className="min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm"
          >
            <option value="all">All six</option>
            {TARGET.map((t) => (
              <option key={t} value={t}>
                Theme {t}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-muted">
          Focus
          <select
            value={focus}
            onChange={(e) => setFocus(e.target.value)}
            className="min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm"
          >
            <option value="all">All focuses</option>
            {FOCI.map((f) => (
              <option key={f}>{f}</option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-muted">
          Budget file
          <select
            value={tier}
            onChange={(e) => setTier(e.target.value as Tier | "all")}
            className="min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm"
          >
            {TIERS.map((t) => (
              <option key={t.id} value={t.id}>
                {t.label}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-muted">
          Phase
          <select
            value={phase}
            onChange={(e) => setPhase(e.target.value as PhaseId | "all")}
            className="min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm"
          >
            <option value="all">All phases</option>
            {(Object.keys(PHASES) as PhaseId[]).map((id) => (
              <option key={id} value={id}>
                {PHASES[id].label} · {PHASES[id].when}
              </option>
            ))}
          </select>
        </label>
      </div>
      <p className="border-b border-line px-3 py-2 text-sm text-muted">
        {rows.length} of {ACTIVITIES.length} activities
        {rows.length > 0 ? ` · own-line amounts ${inr(amount)}` : ""}. Amounts are per GP per year. Convergence and capital lines are ₹0 inside the three files.
      </p>
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="bg-ink text-left text-surface">
              <th className="px-2 py-2 font-semibold">#</th>
              <th className="px-2 py-2 font-semibold">Activity</th>
              <th className="px-2 py-2 font-semibold">Themes</th>
              <th className="px-2 py-2 font-semibold">PAI indicator</th>
              <th className="px-2 py-2 text-right font-semibold">Amount</th>
              <th className="px-2 py-2 font-semibold">File</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((a) => (
              <Fragment key={a.id}>
                <tr className="border-b border-line odd:bg-bg">
                  <td className="px-2 py-2 align-top font-semibold tabular-nums">{a.id}</td>
                  <td className="px-2 py-2 align-top">
                    <button
                      type="button"
                      className="text-left font-semibold"
                      aria-expanded={open === a.id}
                      onClick={() => setOpen(open === a.id ? null : a.id)}
                    >
                      {a.en}
                    </button>
                    <p className="mt-1 text-muted">{a.focus}</p>
                  </td>
                  <td className="px-2 py-2 align-top">
                    <Themes ids={a.themes} />
                  </td>
                  <td className="px-2 py-2 align-top">
                    <span className={a.direction === "Negative" ? "font-semibold text-accent" : "font-semibold text-primary"}>
                      {a.direction === "Negative" ? "Should fall" : "Should rise"}
                    </span>
                    <span className="text-muted"> · {a.link}</span>
                    <p className="mt-1">{a.indicator}</p>
                  </td>
                  <td className="px-2 py-2 text-right align-top font-semibold tabular-nums">
                    {a.amount === 0 ? "—" : inr(a.amount)}
                  </td>
                  <td className="px-2 py-2 align-top">{tierLabel(a.tier)}</td>
                </tr>
                {open === a.id ? (
                  <tr key={`${a.id}-open`} className="border-b border-line bg-bg">
                    <td colSpan={6} className="px-3 py-3">
                      <Booking a={a} />
                    </td>
                  </tr>
                ) : null}
              </Fragment>
            ))}
            {rows.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-3 py-6 text-muted">
                  Nothing matches. Clear a filter.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
      <ul className="md:hidden">
        {rows.map((a) => (
          <li key={a.id} className="border-b border-line p-3">
            <div className="flex items-baseline justify-between gap-3">
              <p className="text-xs font-semibold text-muted">
                {a.id} · {a.focus}
              </p>
              <p className="font-semibold tabular-nums">{a.amount === 0 ? "₹0" : inr(a.amount)}</p>
            </div>
            <button
              type="button"
              className="mt-1 text-left font-semibold"
              aria-expanded={open === a.id}
              onClick={() => setOpen(open === a.id ? null : a.id)}
            >
              {a.en}
            </button>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Themes ids={a.themes} />
              <span className="text-xs text-muted">{tierLabel(a.tier)}</span>
            </div>
            {open === a.id ? (
              <div className="mt-3 border-t border-line pt-3">
                <Booking a={a} />
              </div>
            ) : null}
          </li>
        ))}
        {rows.length === 0 ? <li className="p-3 text-muted">Nothing matches. Clear a filter.</li> : null}
      </ul>
    </div>
  );
}
