import { writeFileSync } from "node:fs";
import * as XLSX from "xlsx";
import {
  catalogueRows,
  gpRows,
  indicatorRows,
  packageRows,
  readmeRows,
} from "../src/lib/workbook-rows.ts";

const wb = XLSX.utils.book_new();

function add(name: string, rows: (string | number)[][], widths: number[]) {
  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws["!cols"] = widths.map((wch) => ({ wch }));
  XLSX.utils.book_append_sheet(wb, ws, name);
}

add("Read me", readmeRows(), [110]);
add(
  "Catalogue",
  catalogueRows(),
  [6, 28, 60, 50, 40, 55, 14, 16, 18, 28, 40, 40, 22, 40, 14, 14, 8, 14, 14, 14, 14, 60],
);
add("Package 50000", packageRows(50000), [6, 28, 50, 55, 16, 50, 14, 18, 28, 40, 22, 14, 8, 12, 14]);
add("Package 1 lakh", packageRows(100000), [6, 28, 50, 55, 16, 50, 14, 18, 28, 40, 22, 14, 8, 12, 14]);
add("Package 2 lakh", packageRows(200000), [6, 28, 50, 55, 16, 50, 14, 18, 28, 40, 22, 14, 8, 12, 14]);
add("Balumath GPs", gpRows(), [14, 18, 12, 10, 16, 10, 14, 10, 14, 10, 16, 10, 14, 10, 14, 10, 14, 10, 16, 10, 14, 10, 14, 18, 50, 40, 70]);
add("Indicator map", indicatorRows(), [70, 14, 18, 22, 16, 24, 28]);

const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
const path = "public/Balumath-GPDP-Child-Protection-Catalogue.xlsx";
writeFileSync(path, buf);
console.log(`wrote ${path} (${buf.length} bytes)`);
