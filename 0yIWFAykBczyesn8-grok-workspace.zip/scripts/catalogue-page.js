var inrFmt = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});
var numFmt = new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 });

function inr(n) {
  return inrFmt.format(n);
}

function num(n) {
  return numFmt.format(n);
}

function esc(s) {
  return String(s)
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/"/g, """);
}

var SHEETS = [
  ["catalogue", "Catalogue"],
  ["50", "₹50,000"],
  ["100", "₹1 lakh"],
  ["200", "₹2 lakh"],
  ["gp", "13 GPs"],
  ["enter", "How to enter"],
];

var AMOUNT = { "50": 50000, "100": 100000, "200": 200000 };

var TIERS = [
  ["all", "All files"],
  ["50", "All three budgets"],
  ["100", "From ₹1 lakh"],
  ["200", "₹2 lakh only"],
  ["conv", "Convergence"],
  ["capex", "Capital"],
];

var state = {
  sheet: "catalogue",
  q: "",
  theme: "all",
  focus: "all",
  tier: "all",
  phase: "all",
  open: null,
  openGp: null,
};

function tierLabel(tier) {
  if (tier === "50") return "All three budgets";
  if (tier === "100") return "₹1 lakh and ₹2 lakh";
  if (tier === "200") return "₹2 lakh only";
  if (tier === "conv") return "Convergence · ₹0";
  return "Capital · separate";
}

function directionWord(d) {
  return d === "Positive" ? "Should rise" : "Should fall";
}

function phaseText(id) {
  var p = DATA.phases[id];
  return p.label + " · " + p.when;
}

function packageIncludes(a, amount) {
  if (a.tier === "conv" || a.tier === "capex") return false;
  if (amount === 50000) return a.tier === "50";
  if (amount === 100000) return a.tier === "50" || a.tier === "100";
  return true;
}

function activitiesIn(amount) {
  return DATA.activities.filter(function (a) {
    return packageIncludes(a, amount);
  });
}

function packageTotal(amount) {
  return activitiesIn(amount).reduce(function (s, a) {
    return s + a.amount;
  }, 0);
}

function activityListText(amount) {
  var lines = activitiesIn(amount);
  var head = "Child-friendly GPDP lines, one GP, " + inr(amount);
  var body = lines
    .map(function (a, i) {
      return i + 1 + ". " + a.hi + " — " + inr(a.amount) + " (Theme " + a.themes.join(", ") + ")";
    })
    .join("\n");
  var total = lines.reduce(function (s, a) {
    return s + a.amount;
  }, 0);
  return head + "\n\n" + body + "\n\nTotal " + inr(total) + "\nFund: GPDP untied / 15th FC basic grant. Not VB–G RAM G wages.";
}

function themes(ids) {
  return (
    '<span class="themes">' +
    ids
      .map(function (id) {
        return '<span class="chip">T' + id + "</span>";
      })
      .join("") +
    "</span>"
  );
}

function gradePill(grade, band) {
  var cls = grade === "D" ? "pill pill-d" : grade === "B" ? "pill pill-b" : "pill pill-c";
  return '<span class="' + cls + '">' + esc(grade) + " · " + esc(band) + "</span>";
}

function booking(a) {
  var dir = a.direction === "Negative" ? "fall" : "rise";
  return (
    '<div class="booking">' +
    '<div><p class="kicker">Paste into eGramSwaraj</p><p class="hi" lang="hi">' +
    esc(a.hi) +
    "</p></div>" +
    '<div><p class="kicker">Booking note</p><p>' +
    esc(a.basis) +
    "</p></div>" +
    "<p><strong>Lead. </strong>" +
    esc(a.lead) +
    '<span class="muted"> with ' +
    esc(a.with) +
    "</span></p>" +
    "<p><strong>Fund. </strong>" +
    esc(a.fund) +
    "</p>" +
    "<p><strong>When. </strong>" +
    esc(phaseText(a.phase)) +
    " — " +
    esc(a.timing) +
    "</p>" +
    '<p><strong>Indicator. </strong><span class="' +
    dir +
    '">' +
    esc(directionWord(a.direction)) +
    '</span><span class="muted"> · ' +
    esc(a.link) +
    " · " +
    esc(a.source) +
    ". </span>" +
    esc(a.indicator) +
    "</p></div>"
  );
}

function options(list, current) {
  return list
    .map(function (pair) {
      var sel = String(pair[0]) === String(current) ? " selected" : "";
      return '<option value="' + esc(pair[0]) + '"' + sel + ">" + esc(pair[1]) + "</option>";
    })
    .join("");
}

function filtered() {
  var query = state.q.trim().toLowerCase();
  return DATA.activities.filter(function (a) {
    if (state.theme !== "all" && a.themes.indexOf(Number(state.theme)) === -1) return false;
    if (state.focus !== "all" && a.focus !== state.focus) return false;
    if (state.tier !== "all" && a.tier !== state.tier) return false;
    if (state.phase !== "all" && a.phase !== state.phase) return false;
    if (!query) return true;
    var blob = [a.id, a.focus, a.en, a.hi, a.indicator, a.lead, a.fund, a.source]
      .join(" ")
      .toLowerCase();
    return blob.indexOf(query) !== -1;
  });
}

function catRow(a, zebra) {
  var open = state.open === a.id;
  var dir = a.direction === "Negative" ? "fall" : "rise";
  var amt = a.amount === 0 ? "—" : inr(a.amount);
  return (
    '<tr class="line' +
    (zebra ? " zebra" : "") +
    '"><td class="tabnum strong">' +
    a.id +
    '</td><td><button type="button" class="name" data-open="' +
    a.id +
    '" aria-expanded="' +
    (open ? "true" : "false") +
    '">' +
    esc(a.en) +
    '</button><p class="muted tight">' +
    esc(a.focus) +
    "</p></td><td>" +
    themes(a.themes) +
    '</td><td><span class="' +
    dir +
    '">' +
    esc(directionWord(a.direction)) +
    '</span><span class="muted"> · ' +
    esc(a.link) +
    '</span><p class="tight">' +
    esc(a.indicator) +
    '</p></td><td class="right tabnum strong">' +
    amt +
    "</td><td>" +
    esc(tierLabel(a.tier)) +
    "</td></tr>" +
    (open ? '<tr class="detail"><td colspan="6">' + booking(a) + "</td></tr>" : "")
  );
}

function catCard(a) {
  var open = state.open === a.id;
  var amt = a.amount === 0 ? "₹0" : inr(a.amount);
  return (
    "<li><div class=\"between\"><p class=\"muted tight\">" +
    a.id +
    " · " +
    esc(a.focus) +
    '</p><p class="strong tabnum">' +
    amt +
    '</p></div><button type="button" class="name" data-open="' +
    a.id +
    '" aria-expanded="' +
    (open ? "true" : "false") +
    '">' +
    esc(a.en) +
    '</button><div class="between" style="justify-content:flex-start;gap:8px;margin-top:8px">' +
    themes(a.themes) +
    '<span class="muted" style="font-size:0.75rem">' +
    esc(tierLabel(a.tier)) +
    "</span></div>" +
    (open ? '<div style="margin-top:12px;border-top:1px solid var(--line);padding-top:12px">' + booking(a) + "</div>" : "") +
    "</li>"
  );
}

function fillCatalogue() {
  var rows = filtered();
  var amount = rows.reduce(function (s, a) {
    return s + a.amount;
  }, 0);
  var count = document.getElementById("count");
  count.textContent =
    rows.length +
    " of " +
    DATA.activities.length +
    " activities" +
    (rows.length ? " · own-line amounts " + inr(amount) : "") +
    ". Amounts are per GP per year. Convergence and capital lines are ₹0 inside the three files.";
  var desk =
    '<div class="table-wrap desk"><table class="wide"><thead><tr><th>#</th><th>Activity</th><th>Themes</th><th>PAI indicator</th><th class="right">Amount</th><th>File</th></tr></thead><tbody>';
  var mob = '<ul class="cards mob">';
  if (!rows.length) {
    desk += '<tr><td colspan="6" class="empty">Nothing matches. Clear a filter.</td></tr>';
    mob += '<li class="empty">Nothing matches. Clear a filter.</li>';
  } else {
    rows.forEach(function (a, i) {
      desk += catRow(a, i % 2 === 1);
      mob += catCard(a);
    });
  }
  desk += "</tbody></table></div>";
  mob += "</ul>";
  document.getElementById("results").innerHTML = desk + mob;
}

function viewCatalogue() {
  var phaseOpts = [["all", "All phases"]].concat(
    Object.keys(DATA.phases).map(function (id) {
      return [id, DATA.phases[id].label + " · " + DATA.phases[id].when];
    }),
  );
  var themeOpts = [["all", "All six"]].concat(
    DATA.target.map(function (t) {
      return [t, "Theme " + t];
    }),
  );
  var focusOpts = [["all", "All focuses"]].concat(
    DATA.foci.map(function (f) {
      return [f, f];
    }),
  );
  return (
    '<form id="filters" class="filters" role="search">' +
    '<label class="field search">Search<input name="q" value="' +
    esc(state.q) +
    '" placeholder="Activity, indicator, fund, Hindi name" autocomplete="off"></label>' +
    '<label class="field">Theme<select name="theme">' +
    options(themeOpts, state.theme) +
    "</select></label>" +
    '<label class="field">Focus<select name="focus">' +
    options(focusOpts, state.focus) +
    "</select></label>" +
    '<label class="field">Budget file<select name="tier">' +
    options(TIERS, state.tier) +
    "</select></label>" +
    '<label class="field">Phase<select name="phase">' +
    options(phaseOpts, state.phase) +
    "</select></label>" +
    '<div class="field" style="justify-content:flex-end"><button type="button" class="btn btn-ghost" data-clear>Clear filters</button></div>' +
    '</form><p id="count" class="count"></p><div id="results"></div>'
  );
}

function pkgRow(a) {
  var open = state.open === a.id;
  return (
    '<tr class="line"><td class="tabnum strong">' +
    a.id +
    '</td><td><button type="button" class="name" data-open="' +
    a.id +
    '" aria-expanded="' +
    (open ? "true" : "false") +
    '">' +
    esc(a.en) +
    "</button></td><td>" +
    themes(a.themes) +
    "</td><td>" +
    esc(a.indicator) +
    '</td><td class="right tabnum">' +
    esc(a.qty) +
    " " +
    esc(a.unit) +
    '</td><td class="right tabnum">' +
    inr(a.unitCost) +
    '</td><td class="right tabnum strong">' +
    inr(a.amount) +
    "</td></tr>" +
    (open ? '<tr class="detail"><td colspan="7">' + booking(a) + "</td></tr>" : "")
  );
}

function viewPackage(amount) {
  var blur = DATA.blurbs[String(amount)];
  var lines = activitiesIn(amount);
  var groups = DATA.foci
    .map(function (focus) {
      return {
        focus: focus,
        rows: lines.filter(function (a) {
          return a.focus === focus;
        }),
      };
    })
    .filter(function (g) {
      return g.rows.length > 0;
    });
  var desk =
    '<div class="table-wrap desk"><table class="wide"><thead><tr><th>#</th><th>Activity</th><th>Themes</th><th>PAI indicator</th><th class="right">Qty</th><th class="right">Rate</th><th class="right">Amount</th></tr></thead><tbody>';
  var mob = '<div class="mob">';
  groups.forEach(function (g) {
    var sub = g.rows.reduce(function (s, a) {
      return s + a.amount;
    }, 0);
    desk += '<tr class="focus-row"><td colspan="7">' + esc(g.focus) + "</td></tr>";
    mob += '<section><h3 class="group-label">' + esc(g.focus) + "</h3><ul class=\"cards\">";
    g.rows.forEach(function (a) {
      var open = state.open === a.id;
      desk += pkgRow(a);
      mob +=
        '<li><div class="between"><p class="muted tight">' +
        a.id +
        '</p><p class="strong tabnum">' +
        inr(a.amount) +
        '</p></div><button type="button" class="name" data-open="' +
        a.id +
        '" aria-expanded="' +
        (open ? "true" : "false") +
        '">' +
        esc(a.en) +
        '</button><p class="muted tight">' +
        esc(a.qty) +
        " " +
        esc(a.unit) +
        " × " +
        inr(a.unitCost) +
        '</p><div style="margin-top:8px">' +
        themes(a.themes) +
        "</div>" +
        (open
          ? '<div style="margin-top:12px;border-top:1px solid var(--line);padding-top:12px">' + booking(a) + "</div>"
          : "") +
        "</li>";
    });
    desk +=
      '<tr class="sub"><td colspan="6" class="right">Subtotal</td><td class="right tabnum">' +
      inr(sub) +
      "</td></tr>";
    mob +=
      '</ul><p class="subline"><span>Subtotal</span><span class="tabnum">' +
      inr(sub) +
      "</span></p></section>";
  });
  desk +=
    '<tr class="total"><td colspan="6">Total — must equal ' +
    inr(amount) +
    '</td><td class="right tabnum">' +
    inr(packageTotal(amount)) +
    "</td></tr></tbody></table></div>";
  mob +=
    '<p class="grand"><span>Total</span><span class="tabnum">' + inr(packageTotal(amount)) + "</span></p></div>";
  var aside = "";
  if (amount === 200000) {
    aside =
      '<aside class="aside"><h3>Beside this file — not inside the ₹2,00,000</h3><ul>' +
      DATA.activities
        .filter(function (a) {
          return a.tier === "conv" || a.tier === "capex";
        })
        .map(function (a) {
          return (
            "<li><p class=\"muted tight\">" +
            a.id +
            " · " +
            (a.tier === "capex" ? "Capital" : "Convergence") +
            " · ₹0 in this file</p><p class=\"strong\" style=\"margin-top:4px\">" +
            esc(a.en) +
            '</p><p class="hi" lang="hi">' +
            esc(a.hi) +
            "</p><p style=\"margin-top:8px\">" +
            esc(a.fund) +
            "</p></li>"
          );
        })
        .join("") +
      "</ul></aside>";
  }
  return (
    '<header class="sheet-head"><p class="kicker">' +
    esc(blur.file) +
    "</p><h2>" +
    esc(blur.title) +
    "</h2><p>" +
    esc(blur.adds) +
    '</p><p class="refuses">' +
    esc(blur.refuses) +
    '</p><div class="actions"><button type="button" class="btn btn-ghost" data-copy="list" data-amount="' +
    amount +
    '">Copy Hindi list</button><a class="btn btn-primary" href="Balumath-GPDP-Child-Protection-Catalogue.xlsx" download>Excel workbook</a></div></header>' +
    desk +
    mob +
    aside
  );
}

function themeBar(gp, id) {
  var s = gp.t[id];
  var hot = gp.hot.indexOf(id) !== -1;
  var width = Math.max(0, Math.min(100, s.score));
  return (
    '<div class="bar' +
    (hot ? " hot" : "") +
    '"><div class="bar-top"><p class="strong">T' +
    id +
    " " +
    esc(DATA.themeShort[id]) +
    '</p><p class="tabnum">' +
    num(s.score) +
    '</p></div><div class="track"><div class="' +
    (s.grade === "D" ? "fill fill-d" : "fill") +
    '" style="width:' +
    width +
    '%"></div></div><div class="bar-foot">' +
    gradePill(s.grade, s.band) +
    (hot ? '<span class="hot-label">Open first</span>' : "") +
    "</div></div>"
  );
}

function viewGp() {
  var two = DATA.gps.filter(function (g) {
    return g.amount === 200000;
  }).length;
  var one = DATA.gps.length - two;
  var body = DATA.gps
    .map(function (gp) {
      var sheet = gp.amount === 100000 ? "100" : "200";
      return (
        '<details class="gp" data-gp="' +
        esc(gp.code) +
        '"' +
        (state.openGp === gp.code ? " open" : "") +
        '><summary><span class="gp-id"><span class="muted tabnum">#' +
        gp.priority +
        '</span><span class="gp-name">' +
        esc(gp.name) +
        '</span><span class="muted">' +
        esc(gp.code) +
        "</span>" +
        gradePill(gp.overall.grade, gp.overall.band) +
        '<span class="tabnum">' +
        num(gp.overall.score) +
        '</span></span><span class="strong tabnum">' +
        inr(gp.amount) +
        '</span></summary><div class="gp-body"><div class="bars">' +
        DATA.target
          .map(function (id) {
            return themeBar(gp, id);
          })
          .join("") +
        '</div><div><h3 class="section">Why this file</h3><ul class="why">' +
        gp.reasons
          .map(function (r) {
            return "<li>" + esc(r) + "</li>";
          })
          .join("") +
        '</ul></div><div><h3 class="section">Open these lines first</h3><ul class="lines">' +
        gp.first
          .map(function (a) {
            return (
              '<li><div class="between"><span class="strong"><span class="tabnum">' +
              a.id +
              '.</span> <span class="hi" lang="hi">' +
              esc(a.hi) +
              '</span></span><span class="tabnum strong">' +
              inr(a.amount) +
              '</span></div><p class="muted tight">' +
              esc(a.indicator) +
              "</p></li>"
            );
          })
          .join("") +
        '</ul></div><div class="actions"><button type="button" class="btn btn-primary" data-sheet="' +
        sheet +
        '">Open the ' +
        inr(gp.amount) +
        ' file</button><button type="button" class="btn btn-ghost" data-copy="resolution" data-gp="' +
        esc(gp.code) +
        '">Copy Gram Sabha resolution</button><button type="button" class="btn btn-ghost" data-copy="gp-list" data-gp="' +
        esc(gp.code) +
        '">Copy activity list</button></div><pre class="resolution">' +
        esc(gp.resolution) +
        "</pre></div></details>"
      );
    })
    .join("");
  return (
    '<header class="sheet-head"><h2>Which file for which GP</h2><p>Sorted with the weakest overall PAI first. Theme 6 is Beginner in all 13 GPs. Theme 2 is already Performer in 11 — hold it, and do not trade it away. Theme 9 is Beginner only in Balumath GP.</p><p>' +
    two +
    " GPs at " +
    inr(200000) +
    ", " +
    one +
    " GPs at " +
    inr(100000) +
    ". If each adopts the recommendation, the block books <strong>" +
    inr(DATA.blockEnvelope) +
    "</strong> of child-development lines. Themes 4 and 5 are also Beginner in most of these GPs — fund them from JJM and SBM-G, not by raiding this file.</p><p class=\"muted\">Scores are the 2022-23 PAI sheet. Replace them when a later round is available; the rule is on the How to enter sheet.</p></header>" +
    body
  );
}

function viewEnter() {
  var phases = Object.keys(DATA.phases)
    .map(function (id) {
      var p = DATA.phases[id];
      return (
        '<div class="card"><p class="strong">' +
        esc(p.label) +
        " · " +
        esc(p.name) +
        '</p><p class="muted">' +
        esc(p.when) +
        "</p></div>"
      );
    })
    .join("");
  var themesHtml = DATA.target
    .map(function (id) {
      var n = DATA.activities.filter(function (a) {
        return a.themes.indexOf(id) !== -1;
      }).length;
      return (
        '<li class="card"><span class="strong">Theme ' +
        id +
        ". </span>" +
        esc(DATA.themeName[id]) +
        '<p class="muted">' +
        n +
        " activities</p></li>"
      );
    })
    .join("");
  var score = DATA.scorecard
    .map(function (row) {
      var sample = DATA.activities.filter(function (a) {
        return a.indicator === row.indicator;
      })[0];
      var ids = DATA.activities
        .filter(function (a) {
          return a.indicator === row.indicator;
        })
        .map(function (a) {
          return a.id;
        })
        .join(", ");
      return (
        '<tr class="line"><td>' +
        esc(row.indicator) +
        "</td><td>" +
        (sample ? esc(directionWord(sample.direction)) : "") +
        '</td><td class="tabnum">' +
        esc(ids) +
        "</td><td>" +
        esc(row.reviewer) +
        "</td></tr>"
      );
    })
    .join("");
  var steps = DATA.steps
    .map(function (s) {
      return "<li>" + esc(s) + "</li>";
    })
    .join("");
  return (
    '<div class="stack"><section class="prose"><h2>How a Sachiv enters this</h2><p class="muted">Prepared for the FY 2027-28 campaign. The catalogue is the activity master. The three files are ready budgets. The GP sheet says which file, using the 2022-23 PAI baseline.</p><ol class="steps">' +
    steps +
    '</ol></section><section class="callout"><h3 class="h-serif">Negative indicators</h3><p>' +
    esc(DATA.negativeNote) +
    '</p></section><section><h3 class="section">Phases</h3><div class="phases">' +
    phases +
    '</div></section><section><h3 class="section">Themes this catalogue will move</h3><ul class="theme-cards">' +
    themesHtml +
    '</ul></section><section><h3 class="section">Quarterly scorecard</h3><p class="muted" style="max-width:48rem">Review these. They are the PAI lines the activities are written against. While the pension camp (activity 31) runs, also note persons with disabilities still waiting for an assistive device — Theme 7, GP-Entry — even though the device itself is not a rupee line here. Read re-enrolment (activity 10) with girls’ transition as well as the all-child rate.</p><div class="table-wrap"><table class="wide"><thead><tr><th>Indicator</th><th>Direction</th><th>Activities</th><th>Reviewed by</th></tr></thead><tbody>' +
    score +
    '</tbody></table></div></section><section class="prose"><h3 class="section">Fund rule</h3><p>' +
    esc(DATA.fundNote) +
    '</p></section><section class="prose"><h3 class="section">Rule for the recommended file</h3><ul class="rules"><li>₹2,00,000 if overall PAI is Beginner, or Theme 9 is under 45, or Theme 6 is under 32, or Theme 8 is under 39, or Theme 3 is under 41.5, or Theme 7 is under 50.</li><li>Otherwise ₹1,00,000. On the 2022-23 sheet that is Sheregara, Basiya, Ganeshpur and Masiyatu.</li><li>₹50,000 only if the balance is short. Say so in the resolution, and name the deferred lines.</li><li>Health is a relative strength. Keep the VHND and immunisation lines anyway — they protect a Performer score. In Basiya and Chetag, Theme 2 is not yet Performer, so those lines are not optional.</li></ul><div class="actions"><button type="button" class="btn btn-ghost" data-copy="short">Copy a short resolution</button></div></section></div>'
  );
}

function viewFor(sheet) {
  if (sheet === "catalogue") return viewCatalogue();
  if (sheet === "50" || sheet === "100" || sheet === "200") return viewPackage(AMOUNT[sheet]);
  if (sheet === "gp") return viewGp();
  return viewEnter();
}

function paintTabs() {
  var tabs = document.querySelectorAll("#tabs [data-sheet]");
  for (var i = 0; i < tabs.length; i++) {
    var on = tabs[i].getAttribute("data-sheet") === state.sheet;
    tabs[i].className = on ? "tab tab-on" : "tab";
    tabs[i].setAttribute("aria-selected", on ? "true" : "false");
  }
  var label = "Catalogue";
  for (var j = 0; j < SHEETS.length; j++) {
    if (SHEETS[j][0] === state.sheet) label = SHEETS[j][1];
  }
  document.getElementById("print-sheet").textContent = label;
}

function renderPanel() {
  document.getElementById("panel").innerHTML = viewFor(state.sheet);
  if (state.sheet === "catalogue") fillCatalogue();
  paintTabs();
}

function setSheet(id) {
  var known = false;
  for (var i = 0; i < SHEETS.length; i++) {
    if (SHEETS[i][0] === id) known = true;
  }
  if (!known) return;
  state.sheet = id;
  if (location.hash !== "#" + id) history.replaceState(null, "", "#" + id);
  renderPanel();
}

function readFilters() {
  var f = document.getElementById("filters");
  if (!f) return;
  state.q = f.elements.q.value;
  state.theme = f.elements.theme.value;
  state.focus = f.elements.focus.value;
  state.tier = f.elements.tier.value;
  state.phase = f.elements.phase.value;
}

function copyPayload(btn) {
  var code = btn.getAttribute("data-gp");
  var gp = null;
  if (code) {
    for (var i = 0; i < DATA.gps.length; i++) {
      if (DATA.gps[i].code === code) gp = DATA.gps[i];
    }
  }
  var kind = btn.getAttribute("data-copy");
  if (kind === "resolution" && gp) return gp.resolution;
  if (kind === "gp-list" && gp) return gp.list;
  if (kind === "list") return activityListText(Number(btn.getAttribute("data-amount")));
  if (kind === "short") return DATA.shortResolution;
  return "";
}

function copyText(text, btn) {
  var prev = btn.textContent;
  function done() {
    btn.textContent = "Copied";
    setTimeout(function () {
      btn.textContent = prev;
    }, 2000);
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text).then(done, function () {
      fallbackCopy(text);
      done();
    });
  }
  fallbackCopy(text);
  done();
  return Promise.resolve();
}

function fallbackCopy(text) {
  var ta = document.createElement("textarea");
  ta.value = text;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.left = "-9999px";
  document.body.appendChild(ta);
  ta.select();
  try {
    document.execCommand("copy");
  } catch (err) {
    /* ignore */
  }
  ta.remove();
}

function sheetFromHash() {
  var h = location.hash.replace("#", "");
  for (var i = 0; i < SHEETS.length; i++) {
    if (SHEETS[i][0] === h) return h;
  }
  return "catalogue";
}

function boot() {
  if (packageTotal(50000) !== 50000 || packageTotal(100000) !== 100000 || packageTotal(200000) !== 200000) {
    console.error("Package totals do not match the three files");
  }
  state.sheet = sheetFromHash();
  state.openGp = DATA.gps.length ? DATA.gps[0].code : null;
  renderPanel();

  document.body.addEventListener("click", function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var sheetBtn = t.closest("[data-sheet]");
    if (sheetBtn && sheetBtn.closest("#tabs, #panel")) {
      setSheet(sheetBtn.getAttribute("data-sheet"));
      if (sheetBtn.closest("#panel")) {
        var tabs = document.getElementById("tabs");
        if (tabs) tabs.scrollIntoView({ block: "start" });
      }
      return;
    }
    var opener = t.closest("[data-open]");
    if (opener) {
      var id = Number(opener.getAttribute("data-open"));
      state.open = state.open === id ? null : id;
      if (state.sheet === "catalogue") fillCatalogue();
      else renderPanel();
      return;
    }
    var copyBtn = t.closest("[data-copy]");
    if (copyBtn) {
      copyText(copyPayload(copyBtn), copyBtn);
      return;
    }
    if (t.closest("[data-clear]")) {
      state.q = "";
      state.theme = "all";
      state.focus = "all";
      state.tier = "all";
      state.phase = "all";
      state.open = null;
      renderPanel();
      return;
    }
    if (t.closest("[data-print]")) window.print();
  });

  document.body.addEventListener("input", function (e) {
    if (!e.target || !e.target.closest || !e.target.closest("#filters")) return;
    readFilters();
    fillCatalogue();
  });
  document.body.addEventListener("change", function (e) {
    if (!e.target || !e.target.closest || !e.target.closest("#filters")) return;
    readFilters();
    fillCatalogue();
  });
  document.body.addEventListener("submit", function (e) {
    if (e.target && e.target.id === "filters") e.preventDefault();
  });
  document.body.addEventListener(
    "toggle",
    function (e) {
      var d = e.target;
      if (!d || d.tagName !== "DETAILS" || !d.getAttribute("data-gp")) return;
      var code = d.getAttribute("data-gp");
      if (d.open) {
        state.openGp = code;
        var all = document.querySelectorAll("details[data-gp]");
        for (var i = 0; i < all.length; i++) {
          if (all[i] !== d && all[i].open) all[i].open = false;
        }
      } else if (state.openGp === code) {
        state.openGp = null;
      }
    },
    true,
  );
  window.addEventListener("hashchange", function () {
    var next = sheetFromHash();
    if (next !== state.sheet) {
      state.sheet = next;
      renderPanel();
    }
  });
}

boot();
