import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-QjGY13Vb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FOCI = [
	"Child protection",
	"Health, ICDS & mothers",
	"Nutrition",
	"IEC & awareness",
	"Child participation",
	"Vulnerable families",
	"Institutional facilities",
	"Governance & GPDP"
];
var THEME_NAME = {
	2: "Healthy Panchayat",
	3: "Child Friendly Panchayat",
	6: "Self-sufficient Infrastructure in Panchayat",
	7: "Socially Just and Socially Secured Panchayat",
	8: "Panchayat with Good Governance",
	9: "Women Friendly Panchayat"
};
var THEME_SHORT = {
	2: "Healthy",
	3: "Child-friendly",
	6: "Infrastructure",
	7: "Socially just",
	8: "Governance",
	9: "Women-friendly"
};
var TARGET$1 = [
	2,
	3,
	6,
	7,
	8,
	9
];
var PHASES = {
	P1: {
		label: "P1",
		when: "Oct 2026",
		name: "Start now"
	},
	P2: {
		label: "P2",
		when: "Oct–Dec 2026",
		name: "Plan campaign"
	},
	P3: {
		label: "P3",
		when: "by 31 Mar 2027",
		name: "Approve and upload"
	},
	P4: {
		label: "P4",
		when: "Apr 2027–Mar 2028",
		name: "Deliver"
	}
};
var IND = {
	vhnd: "Whether Village Health & Nutrition Day is observed monthly in the Gram Panchayat",
	imm: "Percentage of children aged 9 to under 12 months fully immunised during the reference year",
	anm: "Whether all sanctioned ANM and ASHA posts are filled in the Gram Panchayat",
	mort: "Under-1 mortality per 1,000 live births, and maternal deaths relative to live births",
	nut: "Percentage of children under 5 years who are underweight, stunted or wasted",
	bal: "Whether a Bal Sabha is conducted in the Gram Panchayat during the reference year",
	trans: "Transition rate from primary to upper primary, and from upper primary to secondary",
	ecce: "Percentage of children aged 3–6 years receiving formal pre-school education (ECCE) in the Anganwadi",
	awc: "Percentage of Anganwadi Centres with own building and basic facilities (electricity, drinking water, toilet)",
	school: "Percentage of primary schools with own building and basic facilities, including separate toilets for boys and girls",
	crime: "Whether any crime against children was reported from the Gram Panchayat during the reference year",
	marriageRep: "Whether child marriage was reported from the Gram Panchayat during the reference year",
	marriageAw: "Whether the Gram Panchayat created awareness against child marriage during the reference year",
	missing: "Whether any missing child was reported from the Gram Panchayat during the reference year",
	widow: "Percentage of eligible widows receiving a pension (state scheme / IGNWPS)",
	gs: "Whether Gram Sabha meetings are held and the minutes are on eGramSwaraj",
	mahila: "Whether a Mahila Sabha is conducted in the Gram Panchayat during the reference year",
	sc: "Whether the Standing Committee on women and children meets and records minutes",
	grievance: "Whether a grievance-handling system is available in the Gram Panchayat",
	gpdp: "Whether the GPDP is approved and uploaded on eGramSwaraj before 31 March"
};
var F_UNTIED = "GPDP untied fund / 15th FC basic grant";
var F_NHM = "GPDP untied for logistics and IEC; NHM for vaccine, IFA, ORS and kits";
var F_ICDS = "GPDP untied for the demonstration; ICDS for take-home ration";
var ACTIVITIES = [
	{
		id: 1,
		focus: "Child protection",
		en: "Constitute or re-activate the Village Child Protection Committee, notify members, and display the member list with Childline 1098 at the Panchayat Bhawan.",
		hi: "ग्राम स्तरीय बाल संरक्षण समिति (VCPC) का गठन/पुनर्गठन एवं 1098 का प्रदर्शन",
		themes: [
			7,
			8,
			3
		],
		indicator: IND.crime,
		direction: "Negative",
		link: "Contributory",
		source: "GP-Entry",
		lead: "BDO",
		with: "CDPO, DCPU, Police (thana), Mukhiya",
		fund: F_UNTIED,
		phase: "P1",
		timing: "This month. One sitting to notify members; review quarterly after that.",
		unit: "committee",
		unitCost: 2e3,
		qty: 1,
		amount: 2e3,
		tier: "50",
		basis: "There is no PAI line named VCPC. Signed minutes are how the GP shows it acted on crime, marriage and missing-child reports. ₹2,000 is the sitting and the display board, not an honorarium."
	},
	{
		id: 2,
		focus: "Child protection",
		en: "Open a Child Protection Register (child marriage, child labour, missing children, seasonal migration) and update it every month in the VCPC.",
		hi: "बाल संरक्षण रजिस्टर — बाल विवाह, बाल श्रम, गुमशुदा बच्चे, मौसमी पलायन (मासिक)",
		themes: [
			7,
			9,
			3
		],
		indicator: IND.marriageRep,
		direction: "Negative",
		link: "Contributory",
		source: "GP-Entry",
		lead: "CDPO",
		with: "BDO, AWW, ASHA, Panchayat Sachiv",
		fund: F_UNTIED,
		phase: "P1",
		timing: "Open now. Update before every Gram Sabha.",
		unit: "register set",
		unitCost: 2500,
		qty: 1,
		amount: 2500,
		tier: "50",
		basis: "Child labour has no indicator inside Themes 2, 3, 6, 7, 8 or 9. The register is the evidence behind the yes/no on child marriage and missing children. A new report is not a failure — see the note on negative indicators."
	},
	{
		id: 3,
		focus: "Governance & GPDP",
		en: "Place child protection, child marriage and girls' education on the agenda of four Gram Sabhas and upload the minutes on eGramSwaraj.",
		hi: "चार ग्राम सभाओं में बाल संरक्षण एजेंडा, कार्यवाही eGramSwaraj पर",
		themes: [
			8,
			9,
			3
		],
		indicator: IND.gs,
		direction: "Positive",
		link: "Direct",
		source: "eGramSwaraj",
		lead: "BDO",
		with: "Panchayat Sachiv, Mukhiya, CDPO",
		fund: F_UNTIED,
		phase: "P2",
		timing: "During the people's plan campaign, Oct–Dec 2026, and once more before upload.",
		unit: "Sabha",
		unitCost: 1e3,
		qty: 4,
		amount: 4e3,
		tier: "50",
		basis: "₹1,000 a Sabha for documentation and public notice. Not a sitting fee for elected members."
	},
	{
		id: 4,
		focus: "Child protection",
		en: "Hold four Mahila Sabhas on the prohibition of child marriage, trafficking risk before seasonal migration, and girls staying in school.",
		hi: "चार महिला सभा — बाल विवाह निषेध, तस्करी एवं बालिका शिक्षा",
		themes: [9, 7],
		indicator: IND.mahila,
		direction: "Positive",
		link: "Direct",
		source: "eGramSwaraj",
		lead: "CDPO",
		with: "Mukhiya, AWW, ASHA, BDO",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Campaign months, and once before the marriage season.",
		unit: "Sabha",
		unitCost: 1500,
		qty: 4,
		amount: 6e3,
		tier: "50",
		basis: "Record the Sabha on eGramSwaraj or the Theme 9 process indicator does not move. The agenda must name child marriage, so the separate awareness indicator can also be ticked honestly."
	},
	{
		id: 5,
		focus: "Child participation",
		en: "Hold six Bal Sabhas in which children raise protection, school and Anganwadi concerns, with a written follow-up to the Gram Sabha.",
		hi: "छह बाल सभा, बच्चों की बात का मिनट एवं अनुवर्ती कार्रवाई",
		themes: [3, 8],
		indicator: IND.bal,
		direction: "Positive",
		link: "Direct",
		source: "eGramSwaraj",
		lead: "BEEO",
		with: "CDPO, head teacher, Anganwadi worker",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Start in the campaign. Continue every two months in FY 2027-28.",
		unit: "Sabha",
		unitCost: 1e3,
		qty: 6,
		amount: 6e3,
		tier: "50",
		basis: "₹1,000 covers the minute book, public notice and a simple sitting. Children are not paid."
	},
	{
		id: 6,
		focus: "IEC & awareness",
		en: "Paint child rights, POCSO, Childline 1098 and the prohibition of child marriage on the Panchayat Bhawan, the school and the Anganwadi.",
		hi: "पंचायत भवन, विद्यालय, आंगनवाड़ी पर 1098, POCSO एवं बाल विवाह निषेध भित्ति-लेखन",
		themes: [
			9,
			8,
			7
		],
		indicator: IND.marriageAw,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "BDO",
		with: "CDPO, BEEO, head teacher, AWW",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Complete during the campaign so the GP can photograph it for the plan file.",
		unit: "site",
		unitCost: 3e3,
		qty: 3,
		amount: 9e3,
		tier: "50",
		basis: "Three sites at ₹3,000: paint and a local painter. Photograph each wall for the evidence file."
	},
	{
		id: 7,
		focus: "IEC & awareness",
		en: "Put up four flex boards with 1098, POCSO and the missing-child reporting steps at the haat, the school, the Anganwadi and the GP office.",
		hi: "हाट, विद्यालय, आंगनवाड़ी एवं पंचायत पर हेल्पलाइन फ्लेक्स (चार)",
		themes: [7, 9],
		indicator: IND.missing,
		direction: "Negative",
		link: "Contributory",
		source: "GP-Entry",
		lead: "BDO",
		with: "DCPU, Police (thana), CDPO",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Campaign months. Replace if the board is gone by the monsoon.",
		unit: "board",
		unitCost: 1e3,
		qty: 4,
		amount: 4e3,
		tier: "50",
		basis: "A board creates a reporting channel. A missing-child report that follows is the system working, not a worse score. Do not tell the GP to enter 'No' to protect the indicator."
	},
	{
		id: 8,
		focus: "IEC & awareness",
		en: "Stage one nukkad natak on child marriage and trafficking at the haat or during a local fair, in the language of the village.",
		hi: "बाल विवाह एवं तस्करी पर एक नुक्कड़ नाटक",
		themes: [9, 7],
		indicator: IND.marriageAw,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "CDPO",
		with: "BDO, local cultural team, KAWACH block coordinator where placed",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Once in the campaign, or at the next fair before the marriage season.",
		unit: "performance",
		unitCost: 5e3,
		qty: 1,
		amount: 5e3,
		tier: "50",
		basis: "One local performance. Keep a photograph and the date in the Mahila Sabha minute."
	},
	{
		id: 9,
		focus: "IEC & awareness",
		en: "Run a child-marriage pledge with ward members, ASHA, Anganwadi workers and adolescent groups, and print 500 leaflets.",
		hi: "बाल विवाह निषेध शपथ एवं IEC पत्रक (500)",
		themes: [9],
		indicator: IND.marriageAw,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "CDPO",
		with: "AWW, ASHA, Mukhiya, BEEO",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Campaign, and again before the local marriage season.",
		unit: "leaflet",
		unitCost: 6,
		qty: 500,
		amount: 3e3,
		tier: "50",
		basis: "500 leaflets at ₹6, including the pledge card. Distribution without a Sabha does not justify the awareness tick."
	},
	{
		id: 10,
		focus: "Child protection",
		en: "Identify out-of-school and dropout children, including girls, verify them against UDISE+, and hold one re-enrolment drive with the school management committee.",
		hi: "स्कूल से बाहर बच्चों की पहचान एवं पुनः नामांकन शिविर",
		themes: [3, 9],
		indicator: IND.trans,
		direction: "Positive",
		link: "Direct",
		source: "UDISE+",
		lead: "BEEO",
		with: "Head teacher, CDPO, SMC, AWW",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Before the next academic session, and list names during the campaign.",
		unit: "drive",
		unitCost: 3500,
		qty: 1,
		amount: 3500,
		tier: "50",
		basis: "Enrolment is free. ₹3,500 is the listing camp and forms. Ask the BEEO for the girls' transition figure separately — that is the Theme 9 companion of this indicator. Child labour is not a Theme 3 line; re-enrolment is the response this catalogue can fund."
	},
	{
		id: 11,
		focus: "Vulnerable families",
		en: "Map, ward by ward, families where a child is at higher risk: single parent, orphaned child, disability, extreme poverty, substance dependence.",
		hi: "संवेदनशील परिवारों की वार्ड-वार पहचान",
		themes: [7],
		indicator: IND.widow,
		direction: "Positive",
		link: "Contributory",
		source: "GP-Entry / NSAP",
		lead: "CDPO",
		with: "AWW, ASHA, Panchayat Sachiv, DCPU",
		fund: F_UNTIED,
		phase: "P1",
		timing: "Finish the list this month so camps in the larger packages have names.",
		unit: "survey",
		unitCost: 2e3,
		qty: 1,
		amount: 2e3,
		tier: "50",
		basis: "Mapping does not by itself raise pension coverage. It is the list from which activity 31 (in the ₹2 lakh file) and the Anganwadi home visit work. ₹2,000 is formats and ward rounds."
	},
	{
		id: 12,
		focus: "Child participation",
		en: "Install a child grievance box at the school, the Anganwadi and the GP office, and open all three in the VCPC with a written note of action.",
		hi: "विद्यालय, आंगनवाड़ी, पंचायत में बाल शिकायत पेटी (तीन)",
		themes: [8, 3],
		indicator: IND.grievance,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "BDO",
		with: "BEEO, CDPO, head teacher",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Install during the campaign. Open monthly with the VCPC.",
		unit: "box",
		unitCost: 500,
		qty: 3,
		amount: 1500,
		tier: "50",
		basis: "Three boxes at ₹500. A box that is never opened does not meet the indicator. Record each opening."
	},
	{
		id: 13,
		focus: "Governance & GPDP",
		en: "Compile a PAI evidence file: registers, Sabha minutes, VHND sheets and photographs of wall painting, for the Sachiv and the next assessment.",
		hi: "PAI साक्ष्य संचिका — रजिस्टर, कार्यवाही, फोटो",
		themes: [8],
		indicator: IND.gpdp,
		direction: "Positive",
		link: "Contributory",
		source: "eGramSwaraj",
		lead: "BDO",
		with: "Panchayat Sachiv, CDPO, BEEO",
		fund: F_UNTIED,
		phase: "P3",
		timing: "Open the file now. Close a copy before the plan is uploaded.",
		unit: "file",
		unitCost: 1500,
		qty: 1,
		amount: 1500,
		tier: "50",
		basis: "One box file, photocopies and photo prints. This supports every GP-entry indicator. The upload itself is activity 35."
	},
	{
		id: 14,
		focus: "Health, ICDS & mothers",
		en: "Support all 12 monthly Village Health and Nutrition Days: due list, IEC for mothers, and a place to sit. Vaccines and rations stay on NHM and ICDS.",
		hi: "12 मासिक VHND — सूची, IEC, बैठक व्यवस्था (औषधि NHM से)",
		themes: [2, 3],
		indicator: IND.vhnd,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "Medical Officer In-charge",
		with: "BPM (NHM), ANM, ASHA, CDPO",
		fund: F_NHM,
		phase: "P4",
		timing: "Book the line by 31 March 2027. Hold VHND every month of FY 2027-28. Do not skip a month that falls in the campaign if the current balance allows the same pattern.",
		unit: "VHND",
		unitCost: 750,
		qty: 12,
		amount: 9e3,
		tier: "100",
		basis: "₹750 × 12 for the due list, handouts and sitting. Do not buy vaccines, IFA or take-home ration from this line, and do not book a meal."
	},
	{
		id: 15,
		focus: "Health, ICDS & mothers",
		en: "Hold six mothers' meetings at the Anganwadi on antenatal care, postnatal care, IFA, danger signs and institutional delivery.",
		hi: "आंगनवाड़ी में छह माता बैठक — ANC, PNC, IFA, संस्थागत प्रसव",
		themes: [2, 9],
		indicator: IND.mort,
		direction: "Negative",
		link: "Contributory",
		source: "GP-Entry",
		lead: "Medical Officer In-charge",
		with: "ANM, ASHA, CDPO, AWW",
		fund: F_NHM,
		phase: "P4",
		timing: "Six meetings across FY 2027-28. One may be held during the campaign.",
		unit: "meeting",
		unitCost: 1e3,
		qty: 6,
		amount: 6e3,
		tier: "100",
		basis: "There is no separate PAI line for the meeting. It is booked against maternal deaths and institutional delivery. IFA tablets come from NHM."
	},
	{
		id: 16,
		focus: "Nutrition",
		en: "Run two growth-monitoring drives and update Poshan Tracker the same week for underweight, stunted and wasted children, with NRC referral where the worker marks SAM.",
		hi: "दो वृद्धि-निगरानी अभियान एवं पोषण ट्रैकर अद्यतन",
		themes: [2, 3],
		indicator: IND.nut,
		direction: "Negative",
		link: "Direct",
		source: "Poshan Tracker",
		lead: "CDPO",
		with: "AWW, ANM, Medical Officer In-charge",
		fund: F_ICDS,
		phase: "P4",
		timing: "Poshan Maah (September 2027) and a catch-up in January 2028.",
		unit: "drive",
		unitCost: 2e3,
		qty: 2,
		amount: 4e3,
		tier: "100",
		basis: "₹2,000 a drive for listing and a same-week Tracker update. Take-home ration is not purchased here."
	},
	{
		id: 17,
		focus: "Nutrition",
		en: "Hold two community recipe demonstrations for mothers and adolescent girls, using local food and the take-home ration, at the Anganwadi.",
		hi: "स्थानीय आहार एवं टेक-होम राशन पर दो पोषण प्रदर्शन",
		themes: [2, 3],
		indicator: IND.nut,
		direction: "Negative",
		link: "Contributory",
		source: "Poshan Tracker",
		lead: "CDPO",
		with: "AWW, mothers' group, ANM",
		fund: F_ICDS,
		phase: "P4",
		timing: "One in Poshan Maah 2027 and one in the winter.",
		unit: "demonstration",
		unitCost: 2500,
		qty: 2,
		amount: 5e3,
		tier: "100",
		basis: "₹2,500 covers fuel, local ingredients and a display. The ration itself stays on ICDS."
	},
	{
		id: 18,
		focus: "Health, ICDS & mothers",
		en: "Hold one adolescent-girls' and anaemia camp: haemoglobin where NHM supplies the kit, IFA counselling, and menstrual-hygiene IEC.",
		hi: "किशोरी एनीमिया शिविर — Hb/IFA परामर्श (औषधि NHM से)",
		themes: [2, 9],
		indicator: IND.mort,
		direction: "Negative",
		link: "Contributory",
		source: "GP-Entry",
		lead: "Medical Officer In-charge",
		with: "ANM, ASHA, CDPO, BEEO",
		fund: F_NHM,
		phase: "P4",
		timing: "Once in FY 2027-28, aligned to a VHND. School-going girls included.",
		unit: "camp",
		unitCost: 6e3,
		qty: 1,
		amount: 6e3,
		tier: "100",
		basis: "No PAI line is named 'adolescent anaemia'. The camp supports maternal health and girls' retention. Do not buy IFA or Hb kits from the untied fund."
	},
	{
		id: 19,
		focus: "Nutrition",
		en: "Keep a small transport contingency so a child marked SAM or MAM can be taken to the Nutritional Rehabilitation Centre with the referral slip.",
		hi: "SAM/MAM बच्चों के NRC रेफरल हेतु परिवहन आकस्मिकता",
		themes: [2, 3],
		indicator: IND.nut,
		direction: "Negative",
		link: "Direct",
		source: "Poshan Tracker",
		lead: "CDPO",
		with: "Medical Officer In-charge, AWW, ASHA",
		fund: F_UNTIED,
		phase: "P4",
		timing: "Available all year. Pay only against a referral slip.",
		unit: "contingency",
		unitCost: 4e3,
		qty: 1,
		amount: 4e3,
		tier: "100",
		basis: "Reimburse actual fare. No cash without the NRC referral slip. This line does not buy ration; recovery is what moves the percentage."
	},
	{
		id: 20,
		focus: "Health, ICDS & mothers",
		en: "Provide ECCE play and learning material for children aged 3–6 at the Anganwadi pre-school.",
		hi: "आंगनवाड़ी ECCE खेल एवं शिक्षण सामग्री (3–6 वर्ष)",
		themes: [3],
		indicator: IND.ecce,
		direction: "Positive",
		link: "Direct",
		source: "Poshan Tracker",
		lead: "CDPO",
		with: "AWW, BEEO",
		fund: F_UNTIED,
		phase: "P3",
		timing: "Procure before April 2027 so the new session opens with the material. Saksham Anganwadi may top up if the block has a sanction.",
		unit: "set",
		unitCost: 6e3,
		qty: 1,
		amount: 6e3,
		tier: "100",
		basis: "One set for the GP's Anganwadi pre-school. If the GP has more than one centre, split the set; do not silently exceed ₹6,000."
	},
	{
		id: 21,
		focus: "Institutional facilities",
		en: "Fit a handwash station and a safe drinking-water point at the Anganwadi. This is a minor work, not a new building.",
		hi: "आंगनवाड़ी में हैंडवॉश एवं सुरक्षित पेयजल बिंदु",
		themes: [3, 6],
		indicator: IND.awc,
		direction: "Positive",
		link: "Contributory",
		source: "Poshan Tracker",
		lead: "CDPO",
		with: "BDO, Block Engineer, AWW",
		fund: F_UNTIED,
		phase: "P3",
		timing: "Estimate in the campaign. Finish before the monsoon of 2027 if the plan is approved.",
		unit: "work",
		unitCost: 6e3,
		qty: 1,
		amount: 6e3,
		tier: "100",
		basis: "Moves the 'basic facilities' part of the Anganwadi indicator (water), not 'own building'. A new building is activity 37, on VB–G RAM G, and is outside this amount."
	},
	{
		id: 22,
		focus: "Health, ICDS & mothers",
		en: "Maintain an immunisation due-list register and hold a monthly tracking sitting with the ANM and ASHA so every child aged 9 to under 12 months is listed.",
		hi: "पूर्ण टीकाकरण ड्यू-लिस्ट रजिस्टर एवं मासिक ट्रैकिंग",
		themes: [2],
		indicator: IND.imm,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "Medical Officer In-charge",
		with: "ANM, ASHA, CDPO",
		fund: F_NHM,
		phase: "P1",
		timing: "Start the register this month. The budget line carries paper and one listing camp; sessions themselves are NHM.",
		unit: "register",
		unitCost: 4e3,
		qty: 1,
		amount: 4e3,
		tier: "100",
		basis: "Do not pay a parallel incentive. ASHA incentives stay on NHM. ₹4,000 is the register, the listing and the public due-list."
	},
	{
		id: 23,
		focus: "Health, ICDS & mothers",
		en: "Hold a pre-monsoon camp for children on diarrhoea, malaria, dengue and Japanese encephalitis, with an ORS demonstration for mothers.",
		hi: "मानसून-पूर्व बाल स्वास्थ्य शिविर — दस्त, मलेरिया, डेंगू, JE, ORS",
		themes: [2],
		indicator: IND.mort,
		direction: "Negative",
		link: "Contributory",
		source: "GP-Entry",
		lead: "Medical Officer In-charge",
		with: "BPM (NHM), ANM, ASHA, CDPO",
		fund: F_NHM,
		phase: "P4",
		timing: "April–June 2027. Micro-plan it in the GPDP now.",
		unit: "camp",
		unitCost: 12e3,
		qty: 1,
		amount: 12e3,
		tier: "200",
		basis: "Camp logistics and IEC at ₹12,000. ORS, nets and drugs, if any, come from NHM. There is no separate PAI line for a seasonal camp."
	},
	{
		id: 24,
		focus: "Health, ICDS & mothers",
		en: "Hold a winter camp on pneumonia and cold illness in young children, on a Village Health and Nutrition Day.",
		hi: "शीतकालीन शिविर — निमोनिया एवं सर्दी, VHND के साथ",
		themes: [2],
		indicator: IND.mort,
		direction: "Negative",
		link: "Contributory",
		source: "GP-Entry",
		lead: "Medical Officer In-charge",
		with: "ANM, ASHA, CDPO",
		fund: F_NHM,
		phase: "P4",
		timing: "November 2027–February 2028. If the current year's balance allows, a camp in this winter is additional, not a substitute.",
		unit: "camp",
		unitCost: 6e3,
		qty: 1,
		amount: 6e3,
		tier: "200",
		basis: "₹6,000 logistics. Medicines from NHM. Book it on the FY 2027-28 plan."
	},
	{
		id: 25,
		focus: "Institutional facilities",
		en: "Carry out a minor repair so the primary-school toilet and handwash work, with separate use for girls and boys. Not a new toilet block.",
		hi: "विद्यालय शौचालय एवं हैंडवॉश की लघु मरम्मत (अलग, बालक/बालिका)",
		themes: [3, 6],
		indicator: IND.school,
		direction: "Positive",
		link: "Contributory",
		source: "UDISE+",
		lead: "BEEO",
		with: "BDO, Block Engineer, SMC",
		fund: F_UNTIED,
		phase: "P4",
		timing: "Estimate by March 2027. Repair from April 2027. If no toilet exists, do not force it into ₹18,000 — use activity 38.",
		unit: "repair",
		unitCost: 18e3,
		qty: 1,
		amount: 18e3,
		tier: "200",
		basis: "Ceiling for door, pan, water point and a handwash. A new block is VB–G RAM G Schedule I plus Samagra Shiksha (activity 38), outside this package."
	},
	{
		id: 26,
		focus: "Institutional facilities",
		en: "Carry out a minor repair of the Anganwadi toilet, water connection or electric point. Not a new Anganwadi building.",
		hi: "आंगनवाड़ी शौचालय, जल या बिजली की लघु मरम्मत (नया भवन नहीं)",
		themes: [3, 6],
		indicator: IND.awc,
		direction: "Positive",
		link: "Contributory",
		source: "Poshan Tracker",
		lead: "CDPO",
		with: "BDO, Block Engineer, AWW",
		fund: F_UNTIED,
		phase: "P4",
		timing: "Estimate by March 2027. Repair from April 2027.",
		unit: "repair",
		unitCost: 15e3,
		qty: 1,
		amount: 15e3,
		tier: "200",
		basis: "Moves basic facilities only. Own building is activity 37 and is not paid from this ₹15,000."
	},
	{
		id: 27,
		focus: "Nutrition",
		en: "Start a kitchen garden at the Anganwadi and at the school as a nutrition demonstration, two sites.",
		hi: "आंगनवाड़ी एवं विद्यालय में पोषण वाटिका (दो)",
		themes: [2, 3],
		indicator: IND.nut,
		direction: "Negative",
		link: "Contributory",
		source: "Poshan Tracker",
		lead: "CDPO",
		with: "BEEO, AWW, head teacher, SMC",
		fund: F_UNTIED,
		phase: "P4",
		timing: "Sow at the start of the 2027 monsoon. Book the line now.",
		unit: "garden",
		unitCost: 3e3,
		qty: 2,
		amount: 6e3,
		tier: "200",
		basis: "₹3,000 a site: seed, tools, a simple fence. The garden illustrates the diet; it does not replace the take-home ration."
	},
	{
		id: 28,
		focus: "IEC & awareness",
		en: "Paint handwashing, toilet use, safe drinking water and Poshan messages on the Anganwadi and school walls, for children and mothers.",
		hi: "आंगनवाड़ी एवं विद्यालय पर स्वच्छता व पोषण भित्ति-लेखन",
		themes: [
			2,
			3,
			6
		],
		indicator: IND.vhnd,
		direction: "Positive",
		link: "Contributory",
		source: "GP-Entry",
		lead: "CDPO",
		with: "BEEO, PHED, AWW, head teacher",
		fund: F_UNTIED,
		phase: "P2",
		timing: "During the campaign, after the protection wall painting (activity 6), or in the same contract if the painter is already engaged — still book them as two lines.",
		unit: "site",
		unitCost: 4e3,
		qty: 2,
		amount: 8e3,
		tier: "200",
		basis: "There is no PAI line called wall painting. This one supports VHND behaviour and the child-friendly facility. Two sites at ₹4,000. Do not merge it with activity 6 or the child-marriage message gets crowded out."
	},
	{
		id: 29,
		focus: "IEC & awareness",
		en: "Observe Children's Day (14 November), National Girl Child Day (24 January) and the World Day Against Child Labour (12 June), each with a Bal Sabha.",
		hi: "तीन दिवस — बाल दिवस, बालिका दिवस, बाल श्रम विरोधी दिवस — बाल सभा सहित",
		themes: [
			3,
			9,
			7
		],
		indicator: IND.bal,
		direction: "Positive",
		link: "Direct",
		source: "eGramSwaraj",
		lead: "BEEO",
		with: "CDPO, head teacher, AWW",
		fund: F_UNTIED,
		phase: "P4",
		timing: "12 June 2027, 14 November 2027, 24 January 2028. Children's Day 2026 may be done from the current balance; this line is the next cycle.",
		unit: "day",
		unitCost: 3e3,
		qty: 3,
		amount: 9e3,
		tier: "200",
		basis: "Minute the Bal Sabha on the day or Theme 3 does not move. 24 January is the girls' day (Theme 9). 12 June is the child-labour response this envelope can carry; Theme 1 poverty lines are a different budget."
	},
	{
		id: 30,
		focus: "Child participation",
		en: "Form or re-activate the school Bal Panchayat (child cabinet) and give it a minute book. Hold at least one joint sitting with the Bal Sabha.",
		hi: "विद्यालय बाल पंचायत (चाइल्ड कैबिनेट) गठन एवं किट",
		themes: [3, 8],
		indicator: IND.bal,
		direction: "Positive",
		link: "Contributory",
		source: "eGramSwaraj",
		lead: "BEEO",
		with: "Head teacher, CDPO, DCPU",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Constitute during the campaign so children speak before the plan is frozen.",
		unit: "kit",
		unitCost: 4e3,
		qty: 1,
		amount: 4e3,
		tier: "200",
		basis: "The PAI line is Bal Sabha, not Bal Panchayat. The cabinet counts only if at least one joint sitting is minuted. ₹4,000 is the book and badges, not a uniform budget."
	},
	{
		id: 31,
		focus: "Vulnerable families",
		en: "Hold one enrolment camp for widow, disability and old-age pensions in households where a child's care depends on that income. Also list pending assistive devices.",
		hi: "विधवा, दिव्यांग एवं वृद्धावस्था पेंशन नामांकन शिविर",
		themes: [7],
		indicator: IND.widow,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry / NSAP",
		lead: "CDPO",
		with: "Social welfare, Panchayat Sachiv, AWW",
		fund: "GPDP untied for the camp; NSAP / state scheme for the pension",
		phase: "P2",
		timing: "During the campaign, using the map from activity 11. A second sitting in FY 2027-28 if forms remain.",
		unit: "camp",
		unitCost: 5e3,
		qty: 1,
		amount: 5e3,
		tier: "200",
		basis: "The pension is paid by NSAP or the state scheme, never from this ₹5,000. While the camp runs, record persons with disabilities still waiting for an assistive device — that is the companion Theme 7 indicator (GP-Entry) and has no separate line in this package."
	},
	{
		id: 32,
		focus: "Vulnerable families",
		en: "Identify children for Mission Vatsalya sponsorship or foster care from the vulnerable-family map, and give the Anganwadi worker a home-visit note for each.",
		hi: "मिशन वात्सल्य स्पॉन्सरशिप/फोस्टर केयर पहचान एवं गृह-भ्रमण",
		themes: [7, 2],
		indicator: IND.widow,
		direction: "Positive",
		link: "Contributory",
		source: "GP-Entry / NSAP",
		lead: "CDPO",
		with: "DCPU, AWW, ASHA",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Identification during the campaign. Home visits monthly after that, within the worker's existing round.",
		unit: "round",
		unitCost: 4e3,
		qty: 1,
		amount: 4e3,
		tier: "200",
		basis: "Sponsorship is not itself a PAI percentage. The overlap with Theme 7 is the child in a household without a pension or with a disabled caregiver. ₹4,000 is formats and the visit kit. The sponsorship amount, if sanctioned, is Mission Vatsalya, not this line."
	},
	{
		id: 33,
		focus: "Child participation",
		en: "Conduct one child-led social audit of Anganwadi and school services, and read the findings in the Bal Sabha and the Gram Sabha.",
		hi: "आंगनवाड़ी एवं विद्यालय का एक बाल-सहभागी सामाजिक अंकेक्षण",
		themes: [8, 3],
		indicator: IND.grievance,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "BEEO",
		with: "CDPO, head teacher, AWW, DCPU",
		fund: F_UNTIED,
		phase: "P2",
		timing: "During the campaign, so the findings can still enter this GPDP.",
		unit: "audit",
		unitCost: 4e3,
		qty: 1,
		amount: 4e3,
		tier: "200",
		basis: "₹4,000 for the sitting and the written finding. Children are not paid. File the finding as a grievance, or the indicator is only a meeting."
	},
	{
		id: 34,
		focus: "Governance & GPDP",
		en: "Convene the Standing Committee on women and children four times in the year, with a fixed agenda of the VCPC register, VHND and the child budget.",
		hi: "महिला एवं बाल स्थायी समिति की चार तिमाही बैठक",
		themes: [8, 9],
		indicator: IND.sc,
		direction: "Positive",
		link: "Direct",
		source: "eGramSwaraj / GP-Entry",
		lead: "BDO",
		with: "Mukhiya, CDPO, BEEO, Panchayat Sachiv",
		fund: F_UNTIED,
		phase: "P4",
		timing: "Constitute in the campaign if it is dormant. Then once a quarter in FY 2027-28.",
		unit: "meeting",
		unitCost: 1e3,
		qty: 4,
		amount: 4e3,
		tier: "200",
		basis: "₹1,000 a quarter for notice and minutes. A committee that does not record a decision does not meet the indicator."
	},
	{
		id: 35,
		focus: "Governance & GPDP",
		en: "Facilitate the Gram Sabha, Mahila Sabha and Bal Sabha during the people's plan campaign and enter one visible child-development budget line in the GPDP.",
		hi: "जनयोजना अभियान — ग्राम/महिला/बाल सभा एवं बाल विकास बजट पंक्ति",
		themes: [
			8,
			3,
			9
		],
		indicator: IND.gpdp,
		direction: "Positive",
		link: "Direct",
		source: "eGramSwaraj",
		lead: "BDO",
		with: "Panchayat Sachiv, DPRO's office, CDPO, BEEO",
		fund: F_UNTIED,
		phase: "P2",
		timing: "Now. Upload the approved plan before 31 March 2027.",
		unit: "facilitation",
		unitCost: 5e3,
		qty: 1,
		amount: 5e3,
		tier: "200",
		basis: "₹5,000 is facilitation and documentation of the three Sabhas for this plan, not a second copy of activities 3, 4 and 5. The child-development line must be visible in the upload."
	},
	{
		id: 36,
		focus: "Health, ICDS & mothers",
		en: "Fill every vacant ANM and ASHA post in the Gram Panchayat and confirm both attend each Village Health and Nutrition Day. No amount from the three packages.",
		hi: "रिक्त ANM एवं ASHA पद पूर्ति (अभिसरण, इस लिफाफे से शून्य)",
		themes: [2],
		indicator: IND.anm,
		direction: "Positive",
		link: "Direct",
		source: "GP-Entry",
		lead: "Medical Officer In-charge",
		with: "BPM (NHM), Civil surgeon's office, BDO",
		fund: "Administrative. ₹0 from the three packages",
		phase: "P1",
		timing: "Raise the vacancy this month. It does not wait for the new plan.",
		unit: "post",
		unitCost: 0,
		qty: 0,
		amount: 0,
		tier: "conv",
		basis: "State health / NHM. Putting a notional salary into the ₹1 lakh or ₹2 lakh file would invent money the GP does not have."
	},
	{
		id: 37,
		focus: "Institutional facilities",
		en: "Where the Anganwadi has no building of its own, prepare a separate estimate for an Anganwadi building under VB–G RAM G Schedule I, converged with Mission Saksham Anganwadi 2.0. Do not put it inside the ₹50,000–₹2,00,000 file.",
		hi: "आंगनवाड़ी का अपना भवन — VB–G RAM G + सक्षम आंगनवाड़ी (पूंजीगत)",
		themes: [3, 6],
		indicator: IND.awc,
		direction: "Positive",
		link: "Direct",
		source: "Poshan Tracker",
		lead: "BDO (Programme Officer)",
		with: "Block Engineer, CDPO",
		fund: "VB–G RAM G Schedule I + Mission Saksham Anganwadi 2.0. Not inside ₹50,000–₹2,00,000",
		phase: "P3",
		timing: "Enter the work in the plan now if the GP is eligible. Execution from April 2027. Confirm Schedule I with the Block Programme Coordinator before the upload.",
		unit: "building",
		unitCost: 0,
		qty: 0,
		amount: 0,
		tier: "capex",
		basis: "This is the line that can move 'own building'. Activities 21 and 26 cannot. MGNREGA, 2005 stands repealed from 01.07.2026; the wage-employment window is VB–G RAM G."
	},
	{
		id: 38,
		focus: "Institutional facilities",
		en: "Where the primary school needs a classroom, kitchen shed, compound wall, playground or a new toilet block, prepare a separate estimate under VB–G RAM G Schedule I converged with Samagra Shiksha. Not inside the three packages.",
		hi: "विद्यालय अधोसंरचना — VB–G RAM G + समग्र शिक्षा (पूंजीगत)",
		themes: [3, 6],
		indicator: IND.school,
		direction: "Positive",
		link: "Direct",
		source: "UDISE+",
		lead: "BEEO",
		with: "BDO (Programme Officer), Block Engineer, SMC",
		fund: "VB–G RAM G Schedule I + Samagra Shiksha. Not inside ₹50,000–₹2,00,000",
		phase: "P3",
		timing: "Plan now. Works from April 2027. Activity 25 remains the minor repair if a toilet already exists.",
		unit: "work",
		unitCost: 0,
		qty: 0,
		amount: 0,
		tier: "capex",
		basis: "Confirm current Schedule I eligibility before the Gram Sabha is asked to approve a building."
	}
];
var FUND_NOTE = "MGNREGA, 2005 stands repealed from 01.07.2026 and is replaced by the Viksit Bharat – Guarantee for Rozgar and Ajeevika Mission (Gramin) Act, 2025 (VB–G RAM G). The ₹50,000, ₹1,00,000 and ₹2,00,000 files are GPDP untied fund and 15th Finance Commission basic grant. They are not wage-employment estimates. Book a new Anganwadi building or new school infrastructure only as activities 37 and 38, on VB–G RAM G Schedule I, converged with Mission Saksham Anganwadi 2.0 or Samagra Shiksha. Confirm Schedule I and GP eligibility with the Block Programme Coordinator or rural.gov.in before the plan is frozen. Vaccines, IFA, ORS and take-home ration stay on NHM and ICDS. Pensions stay on NSAP or the state scheme.";
var NEGATIVE_NOTE = "Indicators marked 'Should fall' (child marriage reported, missing children, crime against children, under-1 and maternal deaths, underweight / stunted / wasted) improve when the harm falls, not when the GP stops writing it down. A rise in reports in the first year, with VCPC minutes showing action, means the register is working. Do not coach a Sachiv to enter 'No'.";
var SCORECARD = [
	{
		indicator: IND.vhnd,
		reviewer: "Medical Officer In-charge"
	},
	{
		indicator: IND.imm,
		reviewer: "Medical Officer In-charge"
	},
	{
		indicator: IND.anm,
		reviewer: "Medical Officer In-charge"
	},
	{
		indicator: IND.nut,
		reviewer: "CDPO"
	},
	{
		indicator: IND.ecce,
		reviewer: "CDPO"
	},
	{
		indicator: IND.bal,
		reviewer: "BEEO / CDPO"
	},
	{
		indicator: IND.trans,
		reviewer: "BEEO"
	},
	{
		indicator: IND.awc,
		reviewer: "CDPO"
	},
	{
		indicator: IND.school,
		reviewer: "BEEO"
	},
	{
		indicator: IND.mahila,
		reviewer: "CDPO"
	},
	{
		indicator: IND.marriageAw,
		reviewer: "CDPO"
	},
	{
		indicator: IND.marriageRep,
		reviewer: "CDPO / Police"
	},
	{
		indicator: IND.missing,
		reviewer: "DCPU / Police"
	},
	{
		indicator: IND.crime,
		reviewer: "DCPU / Police"
	},
	{
		indicator: IND.widow,
		reviewer: "CDPO / Social Welfare"
	},
	{
		indicator: IND.grievance,
		reviewer: "BDO"
	},
	{
		indicator: IND.gs,
		reviewer: "BDO"
	},
	{
		indicator: IND.sc,
		reviewer: "BDO"
	},
	{
		indicator: IND.gpdp,
		reviewer: "BDO / DPRO"
	}
];
function packageIncludes(a, amount) {
	if (a.tier === "conv" || a.tier === "capex") return false;
	if (amount === 5e4) return a.tier === "50";
	if (amount === 1e5) return a.tier === "50" || a.tier === "100";
	return true;
}
function activitiesIn(amount) {
	return ACTIVITIES.filter((a) => packageIncludes(a, amount));
}
function packageTotal(amount) {
	return activitiesIn(amount).reduce((s, a) => s + a.amount, 0);
}
function directionWord(d) {
	return d === "Positive" ? "Should rise" : "Should fall";
}
function tierLabel(tier) {
	switch (tier) {
		case "50": return "All three budgets";
		case "100": return "₹1 lakh and ₹2 lakh";
		case "200": return "₹2 lakh only";
		case "conv": return "Convergence · ₹0";
		case "capex": return "Capital · separate";
	}
}
function phaseText(id) {
	const p = PHASES[id];
	return `${p.label} · ${p.when}`;
}
var PACKAGE_BLURB = {
	5e4: {
		file: "GPDP / BAL / CP / 50",
		title: "Protection and awareness",
		adds: "VCPC, registers, four Gram Sabhas, four Mahila Sabhas, six Bal Sabhas, wall painting, flex, one nukkad, pledge leaflets, one re-enrolment drive, vulnerable-family mapping, grievance boxes, evidence file.",
		refuses: "No VHND, no mothers' meetings, no growth monitoring, no ECCE material, no repair. Not the recommended file for any Balumath GP. Use it only when the untied balance cannot reach ₹1 lakh, and write down what is deferred."
	},
	1e5: {
		file: "GPDP / BAL / CP / 100",
		title: "Adds health, ICDS, mothers and nutrition",
		adds: "Everything in the ₹50,000 file, plus 12 VHNDs, six mothers' meetings, growth monitoring, recipe demonstrations, one anaemia camp, SAM referral transport, ECCE material, an Anganwadi water point, and the immunisation due-list.",
		refuses: "No school or Anganwadi repair, no seasonal camp, no pension camp, no Bal Panchayat kit. Recommended where Theme 6 and Theme 8 are weak but not in the worst band, and Theme 2 must not be dropped."
	},
	2e5: {
		file: "GPDP / BAL / CP / 200",
		title: "Full child-friendly file",
		adds: "Everything in the ₹1 lakh file, plus a pre-monsoon camp, a winter camp, minor school-toilet repair, minor Anganwadi repair, two kitchen gardens, WASH wall painting, three child-rights days, Bal Panchayat, a pension camp, Vatsalya identification, a child-led social audit, the standing committee, and GPDP facilitation.",
		refuses: "Still does not build an Anganwadi or a school. Those are activities 37 and 38, booked beside this file on VB–G RAM G."
	}
};
function assertCatalogue() {
	if (ACTIVITIES.length < 30 || ACTIVITIES.length > 40) throw new Error(`Catalogue must be 30–40 activities, found ${ACTIVITIES.length}`);
	const ids = /* @__PURE__ */ new Set();
	for (const a of ACTIVITIES) {
		if (ids.has(a.id)) throw new Error(`Duplicate id ${a.id}`);
		ids.add(a.id);
		if (a.tier === "conv" || a.tier === "capex") {
			if (a.amount !== 0) throw new Error(`Activity ${a.id} should be ₹0`);
		} else if (a.unitCost * a.qty !== a.amount) throw new Error(`Activity ${a.id} rate × qty does not match amount`);
		if (a.themes.length === 0) throw new Error(`Activity ${a.id} has no theme`);
		for (const t of a.themes) if (!TARGET$1.includes(t)) throw new Error(`Activity ${a.id} theme ${t} is out of scope`);
	}
	if (packageTotal(5e4) !== 5e4) throw new Error(`₹50,000 file sums to ${packageTotal(5e4)}`);
	if (packageTotal(1e5) !== 1e5) throw new Error(`₹1 lakh file sums to ${packageTotal(1e5)}`);
	if (packageTotal(2e5) !== 2e5) throw new Error(`₹2 lakh file sums to ${packageTotal(2e5)}`);
	for (const row of SCORECARD) if (!ACTIVITIES.some((a) => a.indicator === row.indicator)) throw new Error(`Scorecard indicator has no activity: ${row.indicator}`);
}
assertCatalogue();
function inr(n) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(n);
}
function num(n) {
	return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(n);
}
var THEME_OFFICIAL = {
	1: "Poverty Free and Enhanced Livelihoods Panchayat",
	2: "Healthy Panchayat",
	3: "Child Friendly Panchayat",
	4: "Water Sufficient Panchayat",
	5: "Clean and Green Panchayat",
	6: "Self-sufficient Infrastructure in Panchayat",
	7: "Socially Just and Socially Secured Panchayat",
	8: "Panchayat with Good Governance",
	9: "Women Friendly Panchayat"
};
function g(score, grade) {
	return {
		score,
		grade,
		band: grade === "B" ? "Performer" : grade === "C" ? "Aspirant" : "Beginner"
	};
}
var GPS = [
	{
		name: "Sheregara",
		code: "113986",
		overall: g(46.82, "C"),
		t: {
			1: g(55.29, "C"),
			2: g(66.67, "B"),
			3: g(46.16, "C"),
			4: g(44.34, "C"),
			5: g(30.54, "D"),
			6: g(34.87, "D"),
			7: g(54.92, "C"),
			8: g(41.62, "C"),
			9: g(58.89, "C")
		}
	},
	{
		name: "Basiya",
		code: "113968",
		overall: g(46.31, "C"),
		t: {
			1: g(64.84, "B"),
			2: g(50, "C"),
			3: g(45.16, "C"),
			4: g(48.65, "C"),
			5: g(31.75, "D"),
			6: g(34.99, "D"),
			7: g(59.33, "C"),
			8: g(43.46, "C"),
			9: g(47.99, "C")
		}
	},
	{
		name: "Ganeshpur",
		code: "113974",
		overall: g(45.03, "C"),
		t: {
			1: g(58.12, "C"),
			2: g(66.67, "B"),
			3: g(43.13, "C"),
			4: g(41.42, "C"),
			5: g(28.39, "D"),
			6: g(32.5, "D"),
			7: g(57.05, "C"),
			8: g(39.04, "D"),
			9: g(53.46, "C")
		}
	},
	{
		name: "Masiyatu",
		code: "113979",
		overall: g(44.98, "C"),
		t: {
			1: g(55.98, "C"),
			2: g(66.67, "B"),
			3: g(44.45, "C"),
			4: g(41.06, "C"),
			5: g(28.36, "D"),
			6: g(33.96, "D"),
			7: g(51.17, "C"),
			8: g(39.83, "D"),
			9: g(56.41, "C")
		}
	},
	{
		name: "Chetag",
		code: "113970",
		overall: g(44.41, "C"),
		t: {
			1: g(58.86, "C"),
			2: g(57.6, "C"),
			3: g(43.12, "C"),
			4: g(39.99, "D"),
			5: g(30.85, "D"),
			6: g(31.98, "D"),
			7: g(54.61, "C"),
			8: g(39.05, "D"),
			9: g(54.6, "C")
		}
	},
	{
		name: "Balu",
		code: "113964",
		overall: g(44.3, "C"),
		t: {
			1: g(57.24, "C"),
			2: g(69.09, "B"),
			3: g(40.46, "C"),
			4: g(40.9, "C"),
			5: g(24.67, "D"),
			6: g(33.45, "D"),
			7: g(53.93, "C"),
			8: g(41.83, "C"),
			9: g(53.98, "C")
		}
	},
	{
		name: "Marang Loiya",
		code: "113978",
		overall: g(44.3, "C"),
		t: {
			1: g(53.99, "C"),
			2: g(66.67, "B"),
			3: g(41.6, "C"),
			4: g(40.06, "C"),
			5: g(30.42, "D"),
			6: g(33.71, "D"),
			7: g(53.08, "C"),
			8: g(38.06, "D"),
			9: g(52.86, "C")
		}
	},
	{
		name: "Bhageya",
		code: "113969",
		overall: g(42.95, "C"),
		t: {
			1: g(48.75, "C"),
			2: g(66.67, "B"),
			3: g(41.97, "C"),
			4: g(40.02, "C"),
			5: g(32.04, "D"),
			6: g(29.11, "D"),
			7: g(50.67, "C"),
			8: g(37.94, "D"),
			9: g(50.77, "C")
		}
	},
	{
		name: "Murpa",
		code: "113980",
		overall: g(42.16, "C"),
		t: {
			1: g(49.93, "C"),
			2: g(66.67, "B"),
			3: g(42.9, "C"),
			4: g(32.73, "D"),
			5: g(28.96, "D"),
			6: g(32.46, "D"),
			7: g(51.55, "C"),
			8: g(37.95, "D"),
			9: g(49, "C")
		}
	},
	{
		name: "Dhadhu",
		code: "113973",
		overall: g(41.87, "C"),
		t: {
			1: g(51.98, "C"),
			2: g(66.67, "B"),
			3: g(40.16, "C"),
			4: g(38.06, "D"),
			5: g(25.89, "D"),
			6: g(28.64, "D"),
			7: g(53.07, "C"),
			8: g(39.99, "D"),
			9: g(47.48, "C")
		}
	},
	{
		name: "Rajvar",
		code: "113982",
		overall: g(41.74, "C"),
		t: {
			1: g(44.78, "C"),
			2: g(66.67, "B"),
			3: g(41.77, "C"),
			4: g(33.7, "D"),
			5: g(30, "D"),
			6: g(32.38, "D"),
			7: g(47.8, "C"),
			8: g(39.67, "D"),
			9: g(49.69, "C")
		}
	},
	{
		name: "Jhabar",
		code: "113977",
		overall: g(41.49, "C"),
		t: {
			1: g(44.32, "C"),
			2: g(66.15, "B"),
			3: g(40.47, "C"),
			4: g(34.38, "D"),
			5: g(35.49, "D"),
			6: g(31.13, "D"),
			7: g(49.37, "C"),
			8: g(39.66, "D"),
			9: g(41.26, "C")
		}
	},
	{
		name: "Balumath",
		code: "113966",
		overall: g(38.89, "D"),
		t: {
			1: g(48.08, "C"),
			2: g(66.67, "B"),
			3: g(41.08, "C"),
			4: g(31.12, "D"),
			5: g(20.03, "D"),
			6: g(36.82, "D"),
			7: g(48.25, "C"),
			8: g(36.39, "D"),
			9: g(38.33, "D")
		}
	}
];
function recommend(gp) {
	const reasons = [];
	if (gp.overall.grade === "D") reasons.push("Overall PAI is Beginner — the only such GP in the block.");
	if (gp.t[9].grade === "D" || gp.t[9].score < 45) reasons.push(`Theme 9 is ${gp.t[9].score} (${gp.t[9].band}) — child marriage, Mahila Sabha and girls' retention need the full file.`);
	if (gp.t[6].score < 32) reasons.push(`Theme 6 is ${gp.t[6].score} — child-serving facilities are a severe gap.`);
	if (gp.t[8].score < 39) reasons.push(`Theme 8 is ${gp.t[8].score} — Sabha, grievance and plan upload are behind.`);
	if (gp.t[3].score < 41.5) reasons.push(`Theme 3 is ${gp.t[3].score} — the child-friendly score is in the bottom of the block.`);
	if (gp.t[7].score < 50) reasons.push(`Theme 7 is ${gp.t[7].score} — the pension camp and the vulnerable-family lines should not be left out.`);
	if (reasons.length > 0) return {
		amount: 2e5,
		reasons
	};
	const hold = [];
	if (gp.t[2].grade !== "B") hold.push(`Theme 2 is ${gp.t[2].score} (${gp.t[2].band}), behind the rest of the block. The ₹1 lakh file keeps health, ICDS and nutrition. The ₹50,000 file drops them.`);
	hold.push("Theme 6 is Beginner here, as in every GP of Balumath. The ₹50,000 file has no facility line — use it only if the untied balance cannot reach ₹1 lakh.");
	return {
		amount: 1e5,
		reasons: hold
	};
}
var TARGET = [
	2,
	3,
	6,
	7,
	8,
	9
];
function hotThemes(gp) {
	const beginners = TARGET.filter((id) => gp.t[id].grade === "D").sort((a, b) => gp.t[a].score - gp.t[b].score);
	const rest = TARGET.filter((id) => !beginners.includes(id)).sort((a, b) => gp.t[a].score - gp.t[b].score);
	return [...beginners, ...rest].slice(0, Math.max(2, beginners.length));
}
function firstActivities(gp) {
	const rec = recommend(gp);
	const hot = new Set(hotThemes(gp));
	return ACTIVITIES.filter((a) => packageIncludes(a, rec.amount) && a.themes.some((t) => hot.has(t))).sort((a, b) => {
		const ah = a.themes.filter((t) => hot.has(t)).length;
		return b.themes.filter((t) => hot.has(t)).length - ah || b.amount - a.amount || a.id - b.id;
	}).slice(0, 6);
}
function rankedGps() {
	return [...GPS].sort((a, b) => a.overall.score - b.overall.score || a.name.localeCompare(b.name)).map((gp, i) => ({
		...gp,
		priority: i + 1
	}));
}
function blockEnvelope() {
	return GPS.reduce((sum, gp) => sum + recommend(gp).amount, 0);
}
function resolution(gp) {
	const rec = recommend(gp);
	const hot = hotThemes(gp).map((id) => `Theme ${id} (${THEME_OFFICIAL[id]})`).join("; ");
	return [
		`Resolution of the Gram Sabha of ${gp.name} Gram Panchayat (code ${gp.code}), Block Balumath, District Latehar.`,
		``,
		`The Gram Sabha resolves to include a child-friendly package of ${inr(rec.amount)} in the GPDP for 2027-28. The lines are the ${inr(rec.amount)} file of the Balumath GPDP Child Protection Activity Catalogue. Priority themes for this GP: ${hot}.`,
		``,
		`The amount will be met from the untied basic grant / GPDP untied fund. Vaccines, IFA, ORS and take-home ration continue from NHM and ICDS. Pensions continue from NSAP or the state scheme. A new Anganwadi building or new school building, if sanctioned, will be booked on VB–G RAM G Schedule I and not inside this amount.`,
		``,
		`The Panchayat Sachiv will enter each activity on eGramSwaraj against the theme in the catalogue and upload the approved plan before 31 March 2027. The Village Child Protection Committee will keep the evidence file for the next PAI.`
	].join("\n");
}
function activityListText(amount, gpName) {
	const lines = ACTIVITIES.filter((a) => packageIncludes(a, amount));
	return `${gpName ? `${gpName} Gram Panchayat — child-friendly GPDP lines, ${inr(amount)}` : `Child-friendly GPDP lines, one GP, ${inr(amount)}`}\n\n${lines.map((a, i) => `${i + 1}. ${a.hi} — ${inr(a.amount)} (Theme ${a.themes.join(", ")})`).join("\n")}\n\nTotal ${inr(lines.reduce((s, a) => s + a.amount, 0))}\nFund: GPDP untied / 15th FC basic grant. Not VB–G RAM G wages.`;
}
function assertGps() {
	if (GPS.length !== 13) throw new Error(`Expected 13 GPs, found ${GPS.length}`);
	const oneLakh = GPS.filter((gp) => recommend(gp).amount === 1e5).map((gp) => gp.name);
	if (oneLakh.slice().sort().join() !== [
		"Sheregara",
		"Basiya",
		"Ganeshpur",
		"Masiyatu"
	].slice().sort().join()) throw new Error(`₹1 lakh GPs changed: ${oneLakh.join(", ")}`);
	if (blockEnvelope() !== 22e5) throw new Error(`Block envelope is ${blockEnvelope()}`);
}
assertGps();
function Themes({ ids }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex flex-wrap gap-1",
		children: ids.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "border border-line bg-bg px-1.5 py-0.5 text-xs font-semibold tracking-wide text-ink",
			children: ["T", id]
		}, id))
	});
}
function GradePill({ grade, band }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `inline-flex items-center rounded-sm px-1.5 py-0.5 text-xs font-semibold ${grade === "D" ? "bg-accent text-accent-fg" : grade === "B" ? "bg-primary text-primary-fg" : "border border-line bg-surface text-ink"}`,
		children: [
			grade,
			" · ",
			band
		]
	});
}
function DirectionMark({ direction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: direction === "Negative" ? "font-semibold text-accent" : "font-semibold text-primary",
		children: directionWord(direction)
	});
}
function Booking({ a }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 text-sm sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-wide text-muted uppercase",
				children: "Paste into eGramSwaraj"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				lang: "hi",
				className: "mt-1 text-base leading-snug",
				children: a.hi
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-wide text-muted uppercase",
				children: "Booking note"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1",
				children: a.basis
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "Lead. "
				}),
				a.lead,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [" with ", a.with]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold",
				children: "Fund. "
			}), a.fund] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "When. "
				}),
				phaseText(a.phase),
				" — ",
				a.timing
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "Indicator. "
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DirectionMark, { direction: a.direction }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [
						" · ",
						a.link,
						" · ",
						a.source,
						". "
					]
				}),
				a.indicator
			] })
		]
	});
}
var TIERS = [
	{
		id: "all",
		label: "All files"
	},
	{
		id: "50",
		label: "All three budgets"
	},
	{
		id: "100",
		label: "From ₹1 lakh"
	},
	{
		id: "200",
		label: "₹2 lakh only"
	},
	{
		id: "conv",
		label: "Convergence"
	},
	{
		id: "capex",
		label: "Capital"
	}
];
function CatalogueView() {
	const [q, setQ] = (0, import_react.useState)("");
	const [theme, setTheme] = (0, import_react.useState)("all");
	const [focus, setFocus] = (0, import_react.useState)("all");
	const [tier, setTier] = (0, import_react.useState)("all");
	const [phase, setPhase] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return ACTIVITIES.filter((a) => {
			if (theme !== "all" && !a.themes.includes(theme)) return false;
			if (focus !== "all" && a.focus !== focus) return false;
			if (tier !== "all" && a.tier !== tier) return false;
			if (phase !== "all" && a.phase !== phase) return false;
			if (!query) return true;
			return `${a.id} ${a.focus} ${a.en} ${a.hi} ${a.indicator} ${a.lead} ${a.fund} ${a.source}`.toLowerCase().includes(query);
		});
	}, [
		q,
		theme,
		focus,
		tier,
		phase
	]);
	const amount = rows.reduce((s, a) => s + a.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-2 border-b border-line p-3 sm:grid-cols-2 lg:grid-cols-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1 text-xs font-semibold text-muted sm:col-span-2",
					children: ["Search", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Activity, indicator, fund, Hindi name",
						className: "min-h-11 border border-line bg-surface px-3 text-base text-ink md:text-sm"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1 text-xs font-semibold text-muted",
					children: ["Theme", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: theme,
						onChange: (e) => setTheme(e.target.value === "all" ? "all" : Number(e.target.value)),
						className: "min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All six"
						}), TARGET$1.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: t,
							children: ["Theme ", t]
						}, t))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1 text-xs font-semibold text-muted",
					children: ["Focus", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: focus,
						onChange: (e) => setFocus(e.target.value),
						className: "min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All focuses"
						}), FOCI.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1 text-xs font-semibold text-muted",
					children: ["Budget file", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: tier,
						onChange: (e) => setTier(e.target.value),
						className: "min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm",
						children: TIERS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: t.id,
							children: t.label
						}, t.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1 text-xs font-semibold text-muted",
					children: ["Phase", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: phase,
						onChange: (e) => setPhase(e.target.value),
						className: "min-h-11 border border-line bg-surface px-2 text-base text-ink md:text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All phases"
						}), Object.keys(PHASES).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: id,
							children: [
								PHASES[id].label,
								" · ",
								PHASES[id].when
							]
						}, id))]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "border-b border-line px-3 py-2 text-sm text-muted",
			children: [
				rows.length,
				" of ",
				ACTIVITIES.length,
				" activities",
				rows.length > 0 ? ` · own-line amounts ${inr(amount)}` : "",
				". Amounts are per GP per year. Convergence and capital lines are ₹0 inside the three files."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hidden overflow-x-auto md:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "bg-ink text-left text-surface",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "#"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "Activity"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "Themes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "PAI indicator"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-right font-semibold",
							children: "Amount"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "File"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-line odd:bg-bg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 align-top font-semibold tabular-nums",
							children: a.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-2 py-2 align-top",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-left font-semibold",
								"aria-expanded": open === a.id,
								onClick: () => setOpen(open === a.id ? null : a.id),
								children: a.en
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted",
								children: a.focus
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 align-top",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Themes, { ids: a.themes })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-2 py-2 align-top",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: a.direction === "Negative" ? "font-semibold text-accent" : "font-semibold text-primary",
									children: a.direction === "Negative" ? "Should fall" : "Should rise"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [" · ", a.link]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1",
									children: a.indicator
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 text-right align-top font-semibold tabular-nums",
							children: a.amount === 0 ? "—" : inr(a.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-2 align-top",
							children: tierLabel(a.tier)
						})
					]
				}), open === a.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
					className: "border-b border-line bg-bg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "px-3 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Booking, { a })
					})
				}, `${a.id}-open`) : null] }, a.id)), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 6,
					className: "px-3 py-6 text-muted",
					children: "Nothing matches. Clear a filter."
				}) }) : null] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "md:hidden",
			children: [rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "border-b border-line p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-muted",
							children: [
								a.id,
								" · ",
								a.focus
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold tabular-nums",
							children: a.amount === 0 ? "₹0" : inr(a.amount)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-1 text-left font-semibold",
						"aria-expanded": open === a.id,
						onClick: () => setOpen(open === a.id ? null : a.id),
						children: a.en
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Themes, { ids: a.themes }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: tierLabel(a.tier)
						})]
					}),
					open === a.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 border-t border-line pt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Booking, { a })
					}) : null
				]
			}, a.id)), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "p-3 text-muted",
				children: "Nothing matches. Clear a filter."
			}) : null]
		})
	] });
}
function CopyButton({ text, label }) {
	const [done, setDone] = (0, import_react.useState)(false);
	const timer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		return () => {
			if (timer.current) clearTimeout(timer.current);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "inline-flex min-h-11 items-center border border-line bg-surface px-3 text-sm font-semibold text-ink transition-colors duration-200 hover:border-primary",
		onClick: async () => {
			try {
				await navigator.clipboard.writeText(text);
				setDone(true);
				if (timer.current) clearTimeout(timer.current);
				timer.current = setTimeout(() => setDone(false), 2e3);
			} catch {
				setDone(false);
			}
		},
		children: done ? "Copied" : label
	});
}
function PackageView({ amount }) {
	const blur = PACKAGE_BLURB[amount];
	const lines = activitiesIn(amount);
	const [open, setOpen] = (0, import_react.useState)(null);
	const groups = FOCI.map((focus) => ({
		focus,
		rows: lines.filter((a) => a.focus === focus)
	})).filter((g) => g.rows.length > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "border-b border-line px-3 py-4 sm:px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-muted uppercase",
					children: blur.file
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-serif text-2xl font-semibold tracking-tight",
					children: blur.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-3xl text-sm",
					children: blur.adds
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-3xl text-sm text-accent",
					children: blur.refuses
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
						text: activityListText(amount),
						label: "Copy Hindi list"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/Balumath-GPDP-Child-Protection-Catalogue.xlsx",
						download: true,
						className: "inline-flex min-h-11 items-center bg-primary px-3 text-sm font-semibold text-primary-fg",
						children: "Excel workbook"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hidden overflow-x-auto md:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "bg-ink text-left text-surface",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "#"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "Activity"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "Themes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 font-semibold",
							children: "PAI indicator"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-right font-semibold",
							children: "Qty"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-right font-semibold",
							children: "Rate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-2 py-2 text-right font-semibold",
							children: "Amount"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
					focus: g.focus,
					rows: g.rows,
					open,
					setOpen
				}, g.focus)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t-4 border-ink bg-bg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						colSpan: 6,
						className: "px-2 py-3 font-serif text-lg font-semibold",
						children: ["Total — must equal ", inr(amount)]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-2 py-3 text-right font-serif text-lg font-semibold tabular-nums",
						children: inr(packageTotal(amount))
					})]
				})] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:hidden",
			children: [groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "bg-bg px-3 py-2 text-sm font-semibold",
					children: g.focus
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: g.rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-b border-line p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-muted",
								children: a.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold tabular-nums",
								children: inr(a.amount)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-1 text-left font-semibold",
							"aria-expanded": open === a.id,
							onClick: () => setOpen(open === a.id ? null : a.id),
							children: a.en
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								a.qty,
								" ",
								a.unit,
								" × ",
								inr(a.unitCost)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Themes, { ids: a.themes })
						}),
						open === a.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 border-t border-line pt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Booking, { a })
						}) : null
					]
				}, a.id)) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex justify-between border-b border-line px-3 py-2 text-sm font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: inr(g.rows.reduce((s, a) => s + a.amount, 0))
					})]
				})
			] }, g.focus)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-baseline justify-between px-3 py-4 font-serif text-xl font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: inr(packageTotal(amount))
				})]
			})]
		}),
		amount === 2e5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "border-t border-line px-3 py-4 sm:px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-lg font-semibold",
				children: "Beside this file — not inside the ₹2,00,000"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-3",
				children: ACTIVITIES.filter((a) => a.tier === "conv" || a.tier === "capex").map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border border-line p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-muted",
							children: [
								a.id,
								" · ",
								a.tier === "capex" ? "Capital" : "Convergence",
								" · ₹0 in this file"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-semibold",
							children: a.en
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							lang: "hi",
							className: "mt-1 text-muted",
							children: a.hi
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: a.fund
						})
					]
				}, a.id))
			})]
		}) : null
	] });
}
function Group({ focus, rows, open, setOpen }) {
	const sub = rows.reduce((s, a) => s + a.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
			className: "bg-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				colSpan: 7,
				className: "px-2 py-2 text-xs font-semibold tracking-wide text-muted uppercase",
				children: focus
			})
		}),
		rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-b border-line",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-2 py-2 align-top font-semibold tabular-nums",
					children: a.id
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-2 py-2 align-top",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-left font-semibold",
						"aria-expanded": open === a.id,
						onClick: () => setOpen(open === a.id ? null : a.id),
						children: a.en
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-2 py-2 align-top",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Themes, { ids: a.themes })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-2 py-2 align-top",
					children: a.indicator
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "px-2 py-2 text-right align-top tabular-nums",
					children: [
						a.qty,
						" ",
						a.unit
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-2 py-2 text-right align-top tabular-nums",
					children: inr(a.unitCost)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-2 py-2 text-right align-top font-semibold tabular-nums",
					children: inr(a.amount)
				})
			]
		}), open === a.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
			className: "border-b border-line bg-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				colSpan: 7,
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Booking, { a })
			})
		}) : null] }, a.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-b border-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				colSpan: 6,
				className: "px-2 py-2 text-right text-sm font-semibold",
				children: "Subtotal"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-2 text-right font-semibold tabular-nums",
				children: inr(sub)
			})]
		})
	] });
}
function GpView({ onOpen }) {
	const ranked = rankedGps();
	const [openCode, setOpenCode] = (0, import_react.useState)(ranked[0]?.code ?? null);
	const twoLakh = ranked.filter((gp) => recommend(gp).amount === 2e5).length;
	const oneLakh = ranked.length - twoLakh;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "border-b border-line px-3 py-4 sm:px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl font-semibold tracking-tight",
				children: "Which file for which GP"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-3xl text-sm",
				children: "Sorted with the weakest overall PAI first. Theme 6 is Beginner in all 13 GPs. Theme 2 is already Performer in 11 — hold it, and do not trade it away. Theme 9 is Beginner only in Balumath GP."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-3xl text-sm",
				children: [
					twoLakh,
					" GPs at ",
					inr(2e5),
					", ",
					oneLakh,
					" GPs at ",
					inr(1e5),
					". If each adopts the recommendation, the block books ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: inr(blockEnvelope())
					}),
					" of child-development lines. Themes 4 and 5 are also Beginner in most of these GPs — fund them from JJM and SBM-G, not by raiding this file."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-3xl text-sm text-muted",
				children: "Scores are the 2022-23 PAI sheet. Replace them when a later round is available; the rule is on the How to enter sheet."
			})
		]
	}), ranked.map((gp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GpRow, {
		gp,
		onOpen,
		open: openCode === gp.code,
		onToggle: (next) => setOpenCode((cur) => next ? gp.code : cur === gp.code ? null : cur)
	}, gp.code))] });
}
function GpRow({ gp, onOpen, open, onToggle }) {
	const rec = recommend(gp);
	const hot = hotThemes(gp);
	const first = firstActivities(gp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "group border-b border-line",
		open,
		onToggle: (e) => onToggle(e.currentTarget.open),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
			className: "flex cursor-pointer flex-wrap items-baseline justify-between gap-2 px-3 py-3 sm:px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex flex-wrap items-baseline gap-x-3 gap-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs font-semibold text-muted tabular-nums",
						children: ["#", gp.priority]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-serif text-lg font-semibold",
						children: gp.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: gp.code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GradePill, {
						grade: gp.overall.grade,
						band: gp.overall.band
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm tabular-nums",
						children: num(gp.overall.score)
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold tabular-nums",
				children: inr(rec.amount)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 px-3 pb-4 sm:px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2 lg:grid-cols-3",
					children: TARGET$1.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeBar, {
						id,
						score: gp.t[id].score,
						grade: gp.t[id].grade,
						band: gp.t[id].band,
						hot: hot.includes(id)
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "Why this file"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1 list-disc pl-5 text-sm",
					children: rec.reasons.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: r }, r))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: "Open these lines first"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 grid gap-2",
					children: first.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold",
								children: [
									a.id,
									". ",
									a.hi
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 tabular-nums",
								children: inr(a.amount)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: a.indicator
						})]
					}, a.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex min-h-11 items-center bg-primary px-3 text-sm font-semibold text-primary-fg",
							onClick: () => onOpen(rec.amount),
							children: [
								"Open the ",
								inr(rec.amount),
								" file"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
							text: resolution(gp),
							label: "Copy Gram Sabha resolution"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
							text: activityListText(rec.amount, gp.name),
							label: "Copy activity list"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "overflow-x-auto border border-line bg-bg p-3 text-sm leading-relaxed whitespace-pre-wrap",
					children: resolution(gp)
				})
			]
		})]
	});
}
function ThemeBar({ id, score, grade, band, hot }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: hot ? "border border-ink p-2" : "border border-line p-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-semibold",
					children: [
						"T",
						id,
						" ",
						THEME_SHORT[id]
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tabular-nums",
					children: num(score)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 h-2 bg-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: grade === "D" ? "h-2 bg-accent" : "h-2 bg-primary",
					style: { width: `${Math.max(0, Math.min(100, score))}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GradePill, {
					grade,
					band
				}), hot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 text-xs font-semibold",
					children: "Open first"
				}) : null]
			})
		]
	});
}
var STEPS = [
	"Open the Gram Panchayat’s GPDP for 2027-28 on eGramSwaraj. Do this during the people’s plan campaign, not after the upload deadline.",
	"On the GP sheet, take the recommended file. ₹50,000 is only a fallback if the untied balance cannot reach ₹1 lakh — record which lines are deferred.",
	"Enter each activity as its own line. Paste the Hindi name. Do not merge the file into one ‘child welfare’ activity.",
	"Tag the themes shown on the line. A line can sit on more than one theme; the indicator column is the one the quarterly review will watch.",
	"Put the rupee amount on the untied basic grant / GPDP untied fund. Leave NHM drugs, ICDS ration, pensions and new buildings off this amount.",
	"Where the link says Contributory, still enter the activity, and do not expect the PAI number to jump from that line alone.",
	"Upload the approved plan before 31 March 2027. Activity 35 exists so this step has a name and a small cost.",
	"Keep the evidence file (activity 13): minutes, the child-protection register, VHND sheets, and photographs of the walls."
];
function EnterView() {
	const byIndicator = /* @__PURE__ */ new Map();
	for (const a of ACTIVITIES) {
		const list = byIndicator.get(a.indicator) ?? [];
		list.push(a.id);
		byIndicator.set(a.indicator, list);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 px-3 py-4 sm:px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl font-semibold tracking-tight",
						children: "How a Sachiv enters this"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Prepared for the FY 2027-28 campaign. The catalogue is the activity master. The three files are ready budgets. The GP sheet says which file, using the 2022-23 PAI baseline."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-4 grid list-decimal gap-3 pl-5 text-sm",
						children: STEPS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: s }, s))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-3xl border border-accent bg-surface p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-lg font-semibold text-accent",
					children: "Negative indicators"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm",
					children: NEGATIVE_NOTE
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-lg font-semibold",
				children: "Phases"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4",
				children: Object.keys(PHASES).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-line p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
						className: "font-semibold",
						children: [
							PHASES[id].label,
							" · ",
							PHASES[id].name
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-sm text-muted",
						children: PHASES[id].when
					})]
				}, id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-lg font-semibold",
				children: "Themes this catalogue will move"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3",
				children: TARGET$1.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border border-line p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold",
							children: [
								"Theme ",
								id,
								". "
							]
						}),
						THEME_NAME[id],
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-muted",
							children: [ACTIVITIES.filter((a) => a.themes.includes(id)).length, " activities"]
						})
					]
				}, id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-lg font-semibold",
					children: "Quarterly scorecard"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-3xl text-sm text-muted",
					children: "Review these. They are the PAI lines the activities are written against. While the pension camp (activity 31) runs, also note persons with disabilities still waiting for an assistive device — Theme 7, GP-Entry — even though the device itself is not a rupee line here. Read re-enrolment (activity 10) with girls’ transition as well as the all-child rate."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full border-collapse text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "bg-ink text-left text-surface",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-semibold",
									children: "Indicator"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-semibold",
									children: "Direction"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-semibold",
									children: "Activities"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-semibold",
									children: "Reviewed by"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: SCORECARD.map((row) => {
							const sample = ACTIVITIES.find((a) => a.indicator === row.indicator);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line align-top",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: row.indicator
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: sample ? directionWord(sample.direction) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2 tabular-nums",
										children: (byIndicator.get(row.indicator) ?? []).join(", ")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-2",
										children: row.reviewer
									})
								]
							}, row.indicator);
						}) })]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-3xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-lg font-semibold",
					children: "Fund rule"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm",
					children: FUND_NOTE
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-lg font-semibold",
						children: "Rule for the recommended file"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 list-disc pl-5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "₹2,00,000 if overall PAI is Beginner, or Theme 9 is under 45, or Theme 6 is under 32, or Theme 8 is under 39, or Theme 3 is under 41.5, or Theme 7 is under 50." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Otherwise ₹1,00,000. On the 2022-23 sheet that is Sheregara, Basiya, Ganeshpur and Masiyatu." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "₹50,000 only if the balance is short. Say so in the resolution, and name the deferred lines." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Health is a relative strength. Keep the VHND and immunisation lines anyway — they protect a Performer score. In Basiya and Chetag, Theme 2 is not yet Performer, so those lines are not optional." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
							text: "The Gram Sabha resolves to adopt the Balumath GPDP Child Protection Activity Catalogue file marked for this Gram Panchayat, to enter each line separately on eGramSwaraj under the theme indicated, to meet the cost from the untied basic grant, and to upload the plan before 31 March 2027. Commodities and new buildings will be converged, not paid from this amount.",
							label: "Copy a short resolution"
						})
					})
				]
			})
		]
	});
}
var TABS = [
	{
		id: "catalogue",
		label: "Catalogue"
	},
	{
		id: "50",
		label: "₹50,000"
	},
	{
		id: "100",
		label: "₹1 lakh"
	},
	{
		id: "200",
		label: "₹2 lakh"
	},
	{
		id: "gp",
		label: "13 GPs"
	},
	{
		id: "enter",
		label: "How to enter"
	}
];
function Home() {
	const [sheet, setSheet] = (0, import_react.useState)("catalogue");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line bg-ink text-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-screen-xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-wide text-primary-fg uppercase",
						children: "Latehar district · Balumath block · PAI 2022-23"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-serif text-2xl font-semibold tracking-tight sm:text-3xl",
						children: "GPDP Child Protection Activity Catalogue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 max-w-2xl text-sm text-surface",
						children: [ACTIVITIES.length, " activities for child protection, health, ICDS, mothers, nutrition and IEC, mapped to Themes 2, 3, 6, 7, 8 and 9. Three files a Gram Panchayat can adopt as they stand."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-surface",
						children: [
							GPS.length,
							" GPs · recommended block envelope ",
							inr(blockEnvelope())
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/Balumath-GPDP-Child-Protection-Catalogue.xlsx",
					download: true,
					className: "no-print inline-flex min-h-11 items-center justify-center bg-primary px-4 text-sm font-semibold text-primary-fg",
					children: "Download Excel workbook"
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-screen-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "no-print sticky top-0 z-20 border-b border-line bg-bg",
					"aria-label": "Workbook sheets",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1 overflow-x-auto px-2 pt-2",
						role: "tablist",
						children: TABS.map((tab) => {
							const on = sheet === tab.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "tab",
								"aria-selected": on,
								className: on ? "min-h-11 shrink-0 border border-b-0 border-line bg-surface px-3 text-sm font-semibold text-ink" : "min-h-11 shrink-0 px-3 text-sm font-semibold text-muted",
								onClick: () => setSheet(tab.id),
								children: tab.label
							}, tab.id);
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-x border-b border-line bg-surface",
					role: "tabpanel",
					children: [
						sheet === "catalogue" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogueView, {}) : null,
						sheet === "50" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageView, { amount: 5e4 }) : null,
						sheet === "100" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageView, { amount: 1e5 }) : null,
						sheet === "200" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageView, { amount: 2e5 }) : null,
						sheet === "gp" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GpView, { onOpen: (amount) => setSheet(amount === 1e5 ? "100" : "200") }) : null,
						sheet === "enter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterView, {}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "px-4 py-6 text-sm text-muted",
					children: "One Gram Panchayat, one year. Amounts are untied-fund ceilings, not estimates under VB–G RAM G. Activity leads are block posts. Confirm dates with the District Panchayat Raj Officer."
				})
			]
		})]
	});
}
//#endregion
export { Home as component };
