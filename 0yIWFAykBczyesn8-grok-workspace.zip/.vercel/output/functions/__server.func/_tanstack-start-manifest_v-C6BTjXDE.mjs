//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C6BTjXDE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CQp3f-Yb.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CQp3f-Yb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Dok0czwh.js"]
	}
} });
//#endregion
export { tsrStartManifest };
